import { axiosInstance } from "./axiosInstance";

export const applyLeave = async (leaveData) => {
  try {
    const response = axiosInstance.post("/Leave/Apply", leaveData);
  } catch (error) {
    console.error("Error applying leave", error);
    throw error;
  }
};
export const fetchLeaveRequests = async (email) => {
  const response = axiosInstance.post("/Leave/Index", email);
  console.log((await response).data);
  return (await response).data;
};
export const detailsLeave = async (id) => {
  const response = axiosInstance.post(`Leave/Details/${id}`);
  return (await response).data;
};

export const updateLeave = async (leaveData) => {
  const response = axiosInstance.post("Leave/update", leaveData);
};

export const viewStatus = async (email) => {
  try {
    const response = axiosInstance.post("/Leave/ViewStatus", email);

    return (await response).data;
  } catch (error) {
    console.error("Error fetching  leave updates", error);
    throw error;
  }
};
