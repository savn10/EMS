//import { getTokenFromCookie } from "../helpers/helper";
import { axiosInstance } from "./axiosInstance";
export const fetchDept = async () => {
  try {
    const resp = axiosInstance.get("/Departments/Index");
    const departmentsData = (await resp).data; // This will contain the JSON returned from the API
    console.log("Fetched Departments  : ", departmentsData);

    return departmentsData;
  } catch (error) {
    // Detailed error handling
    console.error("Error fetching department:", error.message);
  }
};
export const createDepartment = async (deptname) => {
  try {
    const response = await axiosInstance.post("/Departments/Create", deptname);
    return response;
  } catch (error) {
    console.log("Error in creating dept: ", error);
  }
};
