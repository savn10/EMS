import React, { useState } from "react";
import { userRegister } from "../api/userApi";
import { Link, useNavigate } from "react-router-dom";

const Register = () => {
  // State hooks for form inputs and validation
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [role, setRole] = useState("Employee");
  const navigate = useNavigate();

  const [errors, setErrors] = useState({
    email: "",
    password: "",
    confirmPassword: "",
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  // Handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    // Basic validation
    const newErrors = {};

    if (!email) newErrors.email = "Email is required";
    if (!password) newErrors.password = "Password is required";
    if (password !== confirmPassword)
      newErrors.confirmPassword = "Passwords do not match";

    setErrors(newErrors);

    // If no errors, handle form submission (e.g., send data to server)
    if (Object.keys(newErrors).length === 0) {
      const userData = {
        email: email,
        password: password,
        confirmPassword: confirmPassword,
      };

      const response = await userRegister(userData);

      navigate("/signin");

      // Reset form if needed
    }
  };

  return (
    <div className="body1">
      <div className="container ">
        <div className="home-card first1">
          <h1>Register</h1>
          <form onSubmit={handleSubmit}>
            {/* Display any validation error summary */}
            {isSubmitting && Object.keys(errors).length > 0 && (
              <div className="text-danger">Please fix the errors above.</div>
            )}
            <div className="form-group">
              <label htmlFor="email" className="control-label mb-0 mt-2">
                Email
              </label>
              <input
                id="email"
                type="email"
                className="form-control"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
              {errors.email && (
                <span className="text-danger">{errors.email}</span>
              )}
            </div>
            <div className="form-group">
              <label htmlFor="password" className="form-label mb-0 mt-2">
                Password
              </label>
              <input
                id="password"
                type="password"
                className="form-control"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
              {errors.password && (
                <span className="text-danger">{errors.password}</span>
              )}
            </div>
            <div className="form-group">
              <label htmlFor="confirmPassword" className="form-label mb-0 mt-2">
                Confirm Password
              </label>
              <input
                id="confirmPassword"
                type="password"
                className="form-control"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
              />
              {errors.confirmPassword && (
                <span className="text-danger">{errors.confirmPassword}</span>
              )}
            </div>

            <button type="submit" className="btn btn-dark mt-3">
              Register
            </button>
            <div>
              <p>
                Already have an account? <Link to="/signin">Login</Link>
              </p>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default Register;
