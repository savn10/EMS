//import { useNavigate } from "react-router-dom";
import { userLogOut } from "../api/userApi";
import {
  removeTokenCookie,
  removeUserFromLocalStorage,
} from "../helpers/helper";
const Signout = async () => {
  try {
    const resonse = await userLogOut();

    removeTokenCookie("accessToken");
    removeUserFromLocalStorage();

    window.location.reload();
    window.location.href = "/signin";
  } catch (error) {
    console.error("SignIn error:", error);
  }
};

export default Signout;
