import React, { useEffect, useState } from "react";
import "./Employee.css";
import "../../App.css";
import { deleteEmployee, fetchEmployee } from "../../api/employeeApi";
import { useNavigate } from "react-router-dom";

const EmployeeHome = () => {
  const [employees, setEmployees] = useState([]);
  const [change, setChange] = useState(0);
  const navigate = useNavigate();
  useEffect(() => {
    const fetchEmployees = async () => {
      try {
        var userEmail = localStorage.getItem("userEmail");

        userEmail = userEmail.replace(/"/g, "");
        console.log("hello!", userEmail);
        var userData = {
          Email: userEmail,
        };
        console.log(userData, "userData");
        const response = await fetchEmployee(userData);
        setEmployees(response);
      } catch (error) {
        console.log("error fetching employees: ", error);
      }
    };
    fetchEmployees();
  }, [change]);

  const onDeleteClick = async (id) => {
    try {
      const response = await deleteEmployee(id);

      console.log("it is successful", response.data);
      setChange(change + 1);
    } catch (error) {
      console.log("error deleting employee: ", error);
    }
  };
  return (
    <div className="body">
      <h2 className="thickness">ALL EMPLOYEES</h2>
      <button
        className="btn btn-dark mt-2"
        onClick={() => navigate("/Employee")}
      >
        Create Employee
      </button>
      <div className="table-responsive">
        <table className="table table-striped table-bordered mt-2">
          <thead className="thead-dark">
            <tr>
              <th>EmployeeId</th>
              <th>EmployeeName</th>
              <th>Email</th>
              <th>PhoneNumber</th>
              <th>Role</th>
              <th>Department Id</th>
            </tr>
          </thead>
          <tbody>
            {employees.map((emp, index) => (
              <tr key={index}>
                <td>{emp.employeeId}</td>
                <td>{emp.employeeName}</td>
                <td>{emp.email}</td>
                <td>{emp.phoneNumber}</td>
                <td>{emp.role}</td>
                <td>{emp.departmentId}</td>
                <td>
                  <div className="btn-group">
                    <button
                      className="btn btn-secondary btn-sm"
                      onClick={() => onDeleteClick(emp.employeeId)}
                    >
                      Delete
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default EmployeeHome;
