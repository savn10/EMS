import React, { useEffect, useState } from "react";
import { fetchLeaveRequests } from "../../api/leaveApi";
import viewLeave from "../../components/view/viewLeave";
import { useNavigate } from "react-router-dom";
import "./LeaveRequest.css";

const LeaveRequests = () => {
  const email = localStorage.getItem("userEmail");
  const navigate = useNavigate();
  const [leaveRequests, setLeaveRequests] = useState([]);

  useEffect(() => {
    const fetchLeave = async () => {
      try {
        var userEmail = localStorage.getItem("userEmail");
        userEmail = userEmail.replace(/"/g, "");
        var userData = {
          Email: userEmail,
        };

        const result = await fetchLeaveRequests(userData);
        setLeaveRequests(result);
      } catch (error) {
        console.error("Error fetching leave requests", error);
      }
    };
    fetchLeave();
  }, []);

  const onClickViewLeave = async (id) => {
    navigate(`/leave/details/${id}`);
  };

  return (
    <div className="body">
         <h2 className="thickness">Leave Requests</h2>
      <div className="table-responsive">
        <table className="table table-striped table-bordered mt-2">
          <thead className="thead-dark">
            <tr>
              <th>Id</th>
              <th>Start Date</th>
              <th>End Date</th>
              <th>Reason</th>
              <th>Days</th>
              <th>Employee</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {leaveRequests.map((leaveRequest, index) => {
              // Calculate days
              return (
                <tr key={index}>
                  <td>{leaveRequest.id}</td>
                  <td>
                    {new Date(leaveRequest.startDate).toLocaleDateString()}
                  </td>
                  <td>{new Date(leaveRequest.endDate).toLocaleDateString()}</td>
                  <td>{leaveRequest.reason}</td>
                  <td>{leaveRequest.noOfDays}</td>
                  <td>{leaveRequest.employee.employeeName}</td>
                  <td>
                    <button
                      className="btn btn-secondary btn-sm"
                      onClick={() => onClickViewLeave(leaveRequest.id)}
                    >
                      View
                    </button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default LeaveRequests;
