import React, { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { detailsLeave, updateLeave } from "../../api/leaveApi"; // Assuming these API functions exist.
import "./LeaveRequest.css";
const LeaveDetails = () => {
  const { id } = useParams(); // Get the leave request ID from the URL
  const [leave, setLeave] = useState(null);
  const [approversCmnt, setApproversCmnt] = useState("");
  const navigate = useNavigate();

  const [load, setLoad] = useState(false);
  useEffect(() => {
    const fetchLeaveDetails = async () => {
      try {
        const response = await detailsLeave(id); // Fetch leave details by ID
        setLeave(response);
        setLoad(true);
      } catch (error) {
        console.error("Error fetching leave details", error);
      }
    };

    fetchLeaveDetails();
  }, [id]);

  const handleApprove = async (status) => {
    const formData = {
      approversCmnt: approversCmnt,
      status: status,
      id: leave.id,
    };

    try {
      await updateLeave(formData); // Update leave status
      navigate("/LeaveRequests"); // Navigate back to leave requests list after approval
    } catch (error) {
      console.error("Error updating leave", error);
    }
  };

  return (
    <div>
      {load && (
        <>
          <div className="body">
            <div className="container1">
              <div className="home-card second1 ">
                <div className="heading ">Leave Request</div>
                <br></br>
                <dl className="row">
                  <dt className="col-sm-2">ID</dt>
                  <dd className="col-sm-10">{leave.id}</dd>
                  <dt className="col-sm-2">Name</dt>
                  <dd className="col-sm-10">{leave.employee.employeeName}</dd>

                  <dt className="col-sm-2">Start Date</dt>
                  <dd className="col-sm-10">
                    {new Date(leave.startDate).toLocaleDateString()}
                  </dd>

                  <dt className="col-sm-2">End Date</dt>
                  <dd className="col-sm-10">
                    {new Date(leave.endDate).toLocaleDateString()}
                  </dd>

                  <dt className="col-sm-2">Created At</dt>
                  <dd className="col-sm-10">
                    {new Date(leave.createdAt).toLocaleDateString()}
                  </dd>

                  <dt className="col-sm-2">Days</dt>
                  <dd className="col-sm-10">{leave.noOfDays}</dd>
                </dl>

                <form>
                  <div className="form-group mt-1">
                    <label htmlFor="approversCmnt" className="control-label">
                      Approver's Comment
                    </label>
                    <input
                      id="approversCmnt"
                      className="form-control"
                      value={approversCmnt}
                      onChange={(e) => setApproversCmnt(e.target.value)}
                    />
                  </div>

                  <button
                    type="button"
                    className="btn btn-success m-2  btn-sm"
                    onClick={() => handleApprove("Approved")}
                  >
                    Approve
                  </button>

                  <button
                    type="button"
                    className="btn btn-danger m-2 btn-sm"
                    onClick={() => handleApprove("Rejected")}
                  >
                    Reject
                  </button>
                </form>

                <button
                  className="btn btn-secondary btn-sm mt-2"
                  onClick={() => navigate("/LeaveRequests")}
                >
                  Back
                </button>
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
};

export default LeaveDetails;
