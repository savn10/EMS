import { useState } from "react";

import { applyLeave } from "../../api/leaveApi";
import { getUserFromLocalStorage } from "../../helpers/helper";
import "./LeaveRequest.css";
import { useNavigate } from "react-router-dom";
const ApplyLeave = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    startDate: "",
    endDate: "",
    reason: "",
  });

  const [errors, setErrors] = useState({
    startDate: "",
    endDate: "",
    reason: "",
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const newErrors = {};
      const startDate = new Date(formData.startDate);
      const endDate = new Date(formData.endDate);
      const currentDate = new Date();
      const userEmail = getUserFromLocalStorage("userEmail");
      if (!formData.startDate) newErrors.startDate = "Start Date is required";
      if (startDate < currentDate)
        newErrors.startDate = "Start Date can't be in past";
      if (!formData.endDate) newErrors.endDate = "End Date is required";
      if (endDate < startDate)
        newErrors.startDate = "End Date can't be in the past";
      if (!formData.reason) newErrors.reason = "Reason is required";

      if (Object.keys(newErrors).length === 0) {
        const leaveData = {
          UserEmail: userEmail,
          StartDate: formData.startDate,
          EndDate: formData.endDate,
          Reason: formData.reason,
        };

        const response = await applyLeave(leaveData);
        console.log("Form submitted successfully", formData);
      } else {
        setErrors(newErrors);
      }
    } catch (error) {
      console.log("Error applying leave", error);
    }
  };

  return (
    <div className="body ">
      <div className="container1">
        <div className="home-card second1">
          <form onSubmit={handleSubmit}>
            <div className="text-danger"></div>
            <h2>Apply Leave</h2>
            <div className="form-group mt-4 ">
              <label htmlFor="startDate" className="control-label">
                Start Date
              </label>
              <input
                type="date"
                className="form-control"
                id="startDate"
                name="startDate"
                value={formData.startDate}
                onChange={handleChange}
              />
              {errors.startDate && (
                <span className="text-danger">{errors.startDate}</span>
              )}
            </div>

            <div className="form-group mt-1">
              <label htmlFor="endDate" className="control-label">
                End Date
              </label>
              <input
                type="date"
                className="form-control"
                id="endDate"
                name="endDate"
                value={formData.endDate}
                onChange={handleChange}
              />
              {errors.endDate && (
                <span className="text-danger">{errors.endDate}</span>
              )}
            </div>

            <div className="form-group mt-1">
              <label htmlFor="reason">Reason</label>
              <select
                className="form-control"
                id="reason"
                name="reason"
                value={formData.reason}
                onChange={handleChange}
              >
                <option value="">Select a reason</option>
                <option value="Sick Leave">Sick Leave</option>
                <option value="Personal Leave">Personal Leave</option>
                <option value="Vacational Leave">Vacational Leave</option>
                <option value="Medical Leave">Medical Leave</option>
              </select>
              {errors.reason && (
                <span className="text-danger">{errors.reason}</span>
              )}
            </div>

            <div className="form-group">
              <button type="submit" className="btn btn-dark mt-3">
                Apply
              </button>
            </div>
          </form>
          <button
            className="btn btn-dark mt-2"
            onClick={() => navigate("/ViewStatus")}
          >
            View updates
          </button>

          <div className="note-container">
            <h3>Note:</h3>{" "}
            <p>
              If you are applying leave for one day, select the same start date
              and end date.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ApplyLeave;
