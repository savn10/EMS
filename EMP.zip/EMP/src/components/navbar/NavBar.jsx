import { useContext, useEffect } from "react";
import "./NavBar.css";
import { Link } from "react-router-dom";
import Signout from "../../auth/Signout";

export default function NavBar() {
  var a = localStorage.getItem("userRole");

  if (a != null) a = a.slice(1, -1);
  console.log(a);
  console.log(a === "Admin");

  return (
    <div className=" navbar navbar-expand-sm navbar-toggleable-sm navbar-light  border-bottom box-shadow mb-3">
      <div className="container-fluid">
        <Link className="navbar-brand text-light text-max" to="/Dashboard">
          EMS
        </Link>
        <button
          className="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target=".navbar-collapse"
          aria-controls="navbarSupportedContent"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span className="navbar-toggler-icon"></span>
        </button>
        <div className="navbar-collapse collapse d-sm-inline-flex justify-content-between">
          <ul className="navbar-nav flex-grow-1">
            {a === null && (
              <>
                <li className="nav-item">
                  <Link className="nav-link text-light text-min" to="/SignIn">
                    Login
                  </Link>
                </li>
              </>
            )}

            {a === "Admin" && (
              <>
                <li className="nav-item">
                  <Link
                    className="nav-link text-light text-min"
                    to="/EmployeeHome  "
                  >
                    Employees
                  </Link>
                </li>
                <li className="nav-item">
                  <Link
                    className="nav-link text-light text-min"
                    to="/department"
                  >
                    Department
                  </Link>
                </li>
                <li className="nav-item">
                  <Link className="nav-link text-light text-min" to="/Manager">
                    Manager
                  </Link>
                </li>
                <li className="nav-item">
                  <Link
                    className="nav-link text-light text-min"
                    to="/LeaveRequests"
                  >
                    Leave Requests
                  </Link>
                </li>
              </>
            )}

            {a === "Manager" && (
              <>
                <li className="nav-item">
                  <Link
                    className="nav-link text-light text-min"
                    to="/EmployeeHome  "
                  >
                    Employees
                  </Link>
                </li>

                <Link
                  className="nav-link text-light text-min"
                  to="/LeaveRequests"
                >
                  Leave Requests
                </Link>
              </>
            )}
            {a === "Employee" && (
              <>
                <Link className="nav-link text-light text-min" to="/ApplyLeave">
                  Apply
                </Link>
              </>
            )}

            {a != null && (
              <>
                <li className=" btnlogout nav-item ml-auto">
                  <form>
                    <button
                      className="nav-link text-light text-min"
                      onClick={Signout}
                    >
                      logout
                    </button>
                  </form>
                </li>
              </>
            )}
          </ul>
        </div>
      </div>
    </div>
  );
}
