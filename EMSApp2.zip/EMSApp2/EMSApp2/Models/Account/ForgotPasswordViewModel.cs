﻿using System.ComponentModel.DataAnnotations;

namespace EMSApp2.Models.Account
{
    public class ForgotPasswordViewModel
    {

        [Required]
        [EmailAddress]
        public string Email { get; set; }

        public int EId {  get; set; }
        [Display(Name = "New Password")]
        public string NewPassword { get; set; }

        [Compare("NewPassword")]
        public string ConfirmNewPassword { get; set; }
    }
}
