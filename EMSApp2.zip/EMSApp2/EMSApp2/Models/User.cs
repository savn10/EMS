﻿using Microsoft.AspNetCore.Identity;

namespace EMSApp2.Models
{
    public class User : IdentityUser
    {
    }
}
