﻿using System.ComponentModel.DataAnnotations;
using EMSApp2.Models.EMS;

namespace EMSApp2.Models.EMS
{

   
    public class Employee
    {
        [Key]
        [Required]

        public int EmployeeId { get; set; }
        public int ?Id { get; set; }
        [Required(ErrorMessage ="Name is required")]
        [StringLength(30)]
        public  string EmployeeName { get; set; }
       
        public String ?Gender { get; set; }
        [Required(ErrorMessage = "Email is required")]
        [EmailAddress]
       
        public  string Email { get; set; }

        [StringLength(13, MinimumLength = 10, ErrorMessage = "Atleast 10 characters")]
        [Required(ErrorMessage = "phone number is req")]
        public string ?PhoneNumber { get; set; }

        [Required(ErrorMessage = "Role is req")]
        public  String Role { get; set; }

        public DateOnly HireDate { get; set; }

        public int DepartmentId { get; set; }

        public int LeaveDays { get; set; }



        public Department ?Department { get; set; }
        public ICollection<LeaveRequest>  ?LeaveRequest { get; set; }
    }
}

