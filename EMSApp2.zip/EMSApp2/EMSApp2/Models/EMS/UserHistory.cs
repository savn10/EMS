﻿using System.ComponentModel.DataAnnotations;

namespace EMSApp2.Models.EMS
{
    public class UserHistory
    {

        public int Id { get; set; }

        [EmailAddress]
        public string Email { get; set; }

        public DateTime LoginTime { get; set; }
        public DateTime ?LogoutTime { get; set; }


    }
}
