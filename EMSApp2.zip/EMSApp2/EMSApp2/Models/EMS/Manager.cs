﻿using System.ComponentModel.DataAnnotations;

namespace EMSApp2.Models.EMS
{
    public class Manager
    {
        [Key]
        public int ManagerId { get; set; }  // Foreign Key to Employee (this is the Employee who is a Manager)

        public int DepartmentId { get; set; }  // Foreign Key to Department

        // Navigation properties
        public Employee ?ManagerEmployee { get; set; }  // This links to the Employee who is a Manager
        public Department ?Department { get; set; }
    }
}
