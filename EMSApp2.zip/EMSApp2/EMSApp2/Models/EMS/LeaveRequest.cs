﻿using System.ComponentModel.DataAnnotations;

namespace EMSApp2.Models.EMS
{
    public class LeaveRequest
    {

        public int Id { get; set; }

        [Required]
        [DataType(DataType.Date)]
        public DateTime StartDate { get; set; }
        [Required]
        [DataType(DataType.Date)]
        public DateTime EndDate{ get; set; }
        
        
        [Required]
        [StringLength(250)]

        public string Reason {  get; set; }

        public int NoOfDays { get; set;}

        public string Status { get; set; }

        public int EmployeeId {  get; set; }

        public string ?ApproversCmnt { get; set; }

        public Employee Employee { get; set; }

       

        public DateTime CreatedAt { get; set; }


    }
}
