﻿using System.ComponentModel.DataAnnotations;

namespace EMSApp2.Models.EMS
{
    public class LeaveRequestViewModel
    {

        [Required]
        [DataType(DataType.Date)]
        public DateTime StartDate { get; set; }

        [Required]
        [DataType(DataType.Date)]
        public DateTime EndDate { get; set; }

        [Required]
        [StringLength(250)]
        public string Reason { get; set; }
    }
}
