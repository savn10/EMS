﻿using System.ComponentModel.DataAnnotations;

namespace EMSApp2.Models.EMS
{
    public class Department
    {
        [Key]
        public int DepartmentId { get; set; }
        [Required(ErrorMessage = "Name is req")]
        [StringLength(30)]
        public  string DepartmentName { get; set; }

       public ICollection<Employee> ?Employees { get; set; }

    }
}
