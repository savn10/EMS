﻿namespace EMSApp2.Models.EMS
{
    public class Approver
    {
        public string cmnt { get; set; }
    }
}
