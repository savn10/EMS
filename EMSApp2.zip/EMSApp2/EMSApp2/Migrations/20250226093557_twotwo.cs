﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace EMSApp2.Migrations
{
    /// <inheritdoc />
    public partial class twotwo : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "NoOfDays",
                table: "LeaveRequests",
                type: "int",
                nullable: false,
                defaultValue: 0);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "NoOfDays",
                table: "LeaveRequests");
        }
    }
}
