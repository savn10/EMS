﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace EMSApp2.Migrations
{
    /// <inheritdoc />
    public partial class twofour : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
