using EMSApp2.Data;
using EMSApp2.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using EMSApp2.Models.Account;
using System;
using Microsoft.Extensions.Options;


var builder = WebApplication.CreateBuilder(args);



builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));
builder.Services.AddIdentity<User, IdentityRole>(Options =>
{
    Options.Password.RequireNonAlphanumeric = false;
    Options.Password.RequiredLength = 6;
    Options.Password.RequireUppercase = false;
    Options.User.RequireUniqueEmail = true;
    Options.SignIn.RequireConfirmedAccount = false;

    

}).AddEntityFrameworkStores<ApplicationDbContext>().AddDefaultTokenProviders();

builder.Services.ConfigureApplicationCookie(options =>
{
    options.Cookie.IsEssential = true; // Essential for session management
    options.ExpireTimeSpan = TimeSpan.FromMinutes(45); // Time until cookie expires (session cookie by default)
    options.SlidingExpiration = true; // Enable slding expiration, extend session during activity
    options.LoginPath = "/Account/Login"; // Redirect to login page if not authenticated
    options.LogoutPath = "/Account/Logout"; // Redirect to logout page on sign out
   
    options.Cookie.HttpOnly = true; // Protect the cookie from being accessed via JavaScript
    options.Cookie.SameSite = SameSiteMode.Strict; // Strict SameSite policy for cookie
});
builder.Services.AddControllersWithViews();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();
app.UseAuthentication();

app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=NoLogin}/{id?}");
//app.Use(async (context, next) =>
//{
//    // Add Cache-Control header to prevent caching
//    context.Response.Headers["Cache-Control"] = "no-store";
//    context.Response.Headers["Pragma"] = "no-cache";
//    context.Response.Headers["Expires"] = "-1";
//    await next();
//});
using (var scope = app.Services.CreateScope())
{
    var services = scope.ServiceProvider;
    var userManager = services.GetRequiredService<UserManager<User>>();
    var roleManager = services.GetRequiredService<RoleManager<IdentityRole>>();
    await Seed.Initialize(services, userManager, roleManager);
}

app.Run();
