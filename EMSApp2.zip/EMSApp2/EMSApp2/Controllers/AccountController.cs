﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using EMSApp2.Models;
using EMSApp2.Models.Account;
using EMSApp2.Data;
using Microsoft.EntityFrameworkCore;
using Azure.Identity;
using EMSApp2.Models.EMS;
using Microsoft.AspNetCore.Authorization;



namespace EMSApp2.Controllers
{
    public class AccountController : Controller
    {
        private readonly UserManager<User> _userManager;
        private readonly SignInManager<User> _signInManager;
        private readonly RoleManager<IdentityRole> _roleManager;
        private readonly ApplicationDbContext _context;

       

        public AccountController(UserManager<User> userManager, SignInManager<User> signInManager, RoleManager<IdentityRole> roleManager, ApplicationDbContext context)
        {
            this._userManager = userManager;
            this._signInManager = signInManager;
            this._roleManager = roleManager;
            this._context = context;
        }

        [HttpGet]
        public async Task<IActionResult> Register()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> Register(RegisterViewModel model)
        {
            if (ModelState.IsValid)
            {
                var employee = await _context.Employees.FirstOrDefaultAsync(e => e.Email == model.Email);
                if (employee == null)
                {
                    // If the email does not exist in the employee table
                    ModelState.AddModelError(string.Empty, "This email is not registered in the employee database.");
                    return View(model);
                }
                if (employee.Role != model.Role)
                {
                    ModelState.AddModelError(string.Empty, "The role does not match the employee's role in the database.");
                    return View(model);
                }

                User user = new() { UserName = model.Email, Email = model.Email };
                string a = model.Password;
               // Console.WriteLine(a);
                var result = await _userManager.CreateAsync(user,a);

                if (result.Succeeded)
                {
                    var role = model.Role;
                    await _userManager.AddToRoleAsync(user, role);
                    await _signInManager.SignInAsync(user, isPersistent: false);

                    var user1 = await _context.Employees.FirstOrDefaultAsync(e => e.Email == model.Email);

                   

                    return RedirectToAction("Index", "Home");
                }
                else
                {

                    foreach (var error in ModelState.Values.SelectMany(v => v.Errors))
                    {
                        Console.WriteLine(error.ErrorMessage);
                    }
                }
                
            }
            return View();
        }

        [HttpGet]
        public async Task<IActionResult> Login()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> Login(LoginViewModel model)
        {
            if (ModelState.IsValid)
            {
                var user = await _userManager.FindByEmailAsync(model.Email);
                if (user != null)
                {
                    var roles = await _userManager.GetRolesAsync(user);
                    if (roles.Contains("Admin"))
                    {
                        await _userManager.RemoveFromRoleAsync(user, "Employee");


                    }
                    var user1 = await _context.Employees.FirstOrDefaultAsync(e => e.Email == model.Email);

                    if (roles.Contains("Manager") && user1.Role=="Employee" )
                    {
                        await _userManager.RemoveFromRoleAsync(user, "Manager");
                        await _userManager.AddToRoleAsync(user,"Employee");
                    }
                    if (roles.Contains("Employee") && user1.Role == "Manager")
                    {
                        await _userManager.RemoveFromRoleAsync(user, "Employee");
                        await _userManager.AddToRoleAsync(user, "Manager");
                    }


                    var result = await _signInManager.PasswordSignInAsync(user, model.Password, model.RememberMe, false);
                    if (result.Succeeded)
                    {

                        // var user1 = await _context.Employees.FirstOrDefaultAsync(e => e.Email == model.Email);

                        //TempData["NameOfUser"] = user1.EmployeeName;
                        //TempData["RoleOfUser"] = user1.Role;
                        //Console.WriteLine("hiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii");
                        //Console.WriteLine(TempData["NameOfUser"]);
                        //Console.WriteLine(TempData["RoleOfUser"]);
                        //var Username = user1.EmployeeName;
                        //var Userrole = user1.Role;



                        //await _userManager.RemoveFromRoleAsync(user, "Employee");

                        var history = new UserHistory
                        {
                            Email = model.Email,
                            LoginTime = DateTime.Now
                        };

                        _context.UserHistories.Add(history);
                        await _context.SaveChangesAsync();
                        string rolesString = string.Join(", ", roles);
                        Console.WriteLine("please lemme know " + rolesString);
                        Console.WriteLine("please lemme know" + await _userManager.GetRolesAsync(user));
                        return RedirectToAction("Dashboard", "Home");

                        Console.WriteLine("please lemme know"+ await _userManager.GetRolesAsync(user));
                    }
                    ModelState.AddModelError(string.Empty, "Invalid login attempt.");
                }
            }

            return View(model);
        }
        
        public async Task<IActionResult> Logout()
        {
            var user = User.Identity.Name;
            var usersession = await _context.UserHistories.Where(u => u.Email == user && u.LogoutTime == null).OrderByDescending(u=>u.LoginTime).FirstOrDefaultAsync();

            if (usersession != null)
            {
                usersession.LogoutTime = DateTime.Now;
                await _context.SaveChangesAsync();
            }

            await _signInManager.SignOutAsync();
            //HttpContext.Session.Clear(); // Clear session data
            Response.Cookies.Delete(".AspNetCore.Identity.Application");

            return RedirectToAction("NoLogin", "Home");
        }


        public IActionResult ForgotPassword()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> ForgotPassword(ForgotPasswordViewModel model)
        {
            if (ModelState.IsValid) {
                var user = await _userManager.FindByEmailAsync(model.Email);
                if (user != null)
                {
                    var user1 = await _context.Employees.FirstOrDefaultAsync(e=>e.
                    Email == model.Email);

                    if(user1.EmployeeId == model.EId)
                    {
                        var result = await _userManager.RemovePasswordAsync(user);
                        if(result.Succeeded)
                        {
                            result = await _userManager.AddPasswordAsync(user, model.NewPassword);
                            return RedirectToAction("Login", "Account");
                            

                        }
                        else
                        {
                            ModelState.AddModelError("", "Theres an issue!");
                            return View(model);

                        }

                    }
                    else
                    {
                        ModelState.AddModelError("", "Email and EID doesnt match in the DB");
                        return View(model);


                    }
                }
                else
                {
                    ModelState.AddModelError("", "Email Not found!");
                    return View(model);
                }



            }
            else
            {
                return View(model);
            }


            
           
        }
        public IActionResult Index()
        {
            return View();
        }
        [Authorize]
        [HttpGet]
        public async Task<IActionResult> LoginInfo()
        {
            var user = await _userManager.FindByEmailAsync(User.Identity.Name);
            var role = await _userManager.GetRolesAsync(user);

            
            if(role.Contains("Manager"))
            {
                var emp = await _context.Employees.FirstOrDefaultAsync(e => e.Email == User.Identity.Name);

                var managedemp = await _context.Employees.Where(e => e.DepartmentId == emp.DepartmentId).ToListAsync();
                // Assuming managedemp is already in memory (it's a list or something similar)
                var managedEmails = managedemp.Select(e => e.Email).ToList();

                // Now, query the UserHistories table using the preloaded list of emails
                var logininfo1 = await _context.UserHistories
                    .Where(l => l.LogoutTime != null && managedEmails.Contains(l.Email))
                    .ToListAsync();
                return View(logininfo1);
            }

            


            var logininfo = await _context.UserHistories.Where(l=>l.LogoutTime != null ).ToListAsync();
                return View(logininfo);
           
        }
    }
}
