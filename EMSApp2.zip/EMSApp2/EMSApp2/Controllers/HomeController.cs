using System.CodeDom;
using System.Diagnostics;
using EMSApp2.Data;
using EMSApp2.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Authorization;
using EMSApp2.Models.EMS;
using System.Data;
using Microsoft.VisualStudio.Web.CodeGenerators.Mvc.Templates.BlazorIdentity.Pages.Manage;
using Microsoft.AspNetCore.Identity.UI.Services;

namespace EMSApp2.Controllers
{
   
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly UserManager<User> _userManager;
        private readonly SignInManager<User> _signInManager;
       
        private readonly ApplicationDbContext _context;

        

        public HomeController(ILogger<HomeController> logger, UserManager<User> userManager, SignInManager<User> signInManager, ApplicationDbContext context)
        {
            _userManager = userManager;
            _signInManager = signInManager;
            _context = context;
            _logger = logger;
        }

        [Authorize]
        [HttpGet]
        public async Task <IActionResult> Index()
        {

            string userName = User.Identity.Name;

            // Console.WriteLine(userName + "Helloooo");
            // var user = await _userManager.FindByEmailAsync(userName);
            var employee = await _context.Employees.FirstOrDefaultAsync(e => e.Email == userName);
            // ViewBag.RoleOfUser = TempData["RoleOfUser"];
            ViewBag.Emp = employee;
            ViewBag.noofemployees = _context.Employees.Count();



            return View();
        }


        [Authorize]
        [HttpGet]
        public async Task<IActionResult> DashBoard()
        {
            if(! _signInManager.IsSignedIn(User))
            {
                ViewBag.nologin = "nope";
            }


            var user = await _userManager.FindByEmailAsync(User.Identity.Name);
            var role = await _userManager.GetRolesAsync(user);

            var emp = await _context.Employees.FirstOrDefaultAsync(e => e.Email == User.Identity.Name);

            ViewBag.Username = emp.EmployeeName;
            string rolesString = string.Join(", ", role);
            Console.WriteLine(rolesString);

            ViewBag.role = rolesString;

            if (role.Contains("Admin"))
            {
                int male = _context.Employees.Count(e => e.Gender == "Male");
                int tcount = _context.Employees.Count();

                ViewBag.male = male;
                ViewBag.female = tcount - male;

                var departmentCounts = _context.Employees
                                       .GroupBy(e => e.Department)
                                       .Select(g => new
                                       {
                                           Department = g.Key.DepartmentName,
                                           Count = g.Count()
                                       })
                                       .ToList();

                ViewBag.DepartmentCounts = departmentCounts;

                foreach (var department in departmentCounts)
                {
                    Console.WriteLine($"Department: {department.Department}, Employee Count: {department.Count}");
                }

                DateTime today = DateTime.Today;

                int absent = await _context.LeaveRequests.Where(l => l.Status == "Approved" && l.StartDate <= today && l.EndDate >= today).GroupBy(l => l.EmployeeId).CountAsync();
                //.GroupBy(l=>l.EmployeeId).
                Console.WriteLine("absentee : " + absent);

                ViewBag.absentee = absent;
            }

            

            


            else if(role.Contains("Manager"))
            {
                var deptid = await _context.Employees.FirstOrDefaultAsync(e => e.Email == User.Identity.Name);



                int male = _context.Employees.Where(e=>e.DepartmentId==deptid.DepartmentId).Count(e => e.Gender == "Male");



                int tcount = _context.Employees.Where(e => e.DepartmentId == deptid.DepartmentId).Count();

                ViewBag.male = male;
                ViewBag.female = tcount - male;

               

               

                DateTime today = DateTime.Today;

                //int absent = await _context.LeaveRequests.Where(l => l.Status == "Approved" && l.StartDate <= today && l.EndDate >= today).GroupBy(l => l.EmployeeId).CountAsync();
                //.GroupBy(l=>l.EmployeeId).
                int absent = await _context.LeaveRequests
           .Where(l => l.Status == "Approved" && l.StartDate <= today && l.EndDate >= today)
           .Join(_context.Employees, // Join with Employees to filter by department
               leave => leave.EmployeeId,
               employee => employee.EmployeeId,
               (leave, employee) => new { leave, employee })
                .Where(leaveEmployee => leaveEmployee.employee.DepartmentId == deptid.DepartmentId) // Filter by the manager's department
           .GroupBy(leaveEmployee => leaveEmployee.leave.EmployeeId) // Group by EmployeeId to get unique employees
           .CountAsync();
                Console.WriteLine("absentee : " + absent);

                ViewBag.absentee = absent;
               
            }

            else
            {
                return RedirectToAction("Ours", "Home");
            }

            return View();
          
        }









        [Authorize]
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }


        public IActionResult NoLogin()
        {
            if(_signInManager.IsSignedIn(User))
            {

                return RedirectToAction("DashBoard", "Home");

            }


            return View();
        }

        [HttpGet]
        public async  Task<IActionResult> Ours()
        {
            var emp = await _context.Employees.FirstOrDefaultAsync(e => e.Email == User.Identity.Name);

            var leaves = await _context.LeaveRequests.FirstOrDefaultAsync(l => l.EmployeeId == emp.EmployeeId);

            var dept = await _context.Departments.FirstOrDefaultAsync(d => d.DepartmentId == emp.DepartmentId);



            // Get the current date information
            var currentMonth = DateTime.Now.Month;
            var currentYear = DateTime.Now.Year;

            // Count holidays that intersect with the current month
            var holidayCount = await _context.LeaveRequests
                .Where(h => h.EmployeeId == emp.EmployeeId &&h.StartDate.Year == currentYear && h.EndDate.Year == currentYear && h.Status=="Approved" &&
                            ((h.StartDate.Month == currentMonth) ||
                             (h.EndDate.Month == currentMonth) ||
                             (h.StartDate.Month < currentMonth && h.EndDate.Month > currentMonth))).SumAsync(h=>h.NoOfDays);

            //foreach (var leaveRequest in holidayCount)
            //{
            //    Console.WriteLine($"Employee ID: {leaveRequest.EmployeeId}");
            //   // Console.WriteLine($"Leave Type: {leaveRequest.LeaveType}");  // Replace with your LeaveType field if available
            //    Console.WriteLine($"Start Date: {leaveRequest.StartDate.ToShortDateString()}");
            //    Console.WriteLine($"End Date: {leaveRequest.EndDate.ToShortDateString()}");
            //    Console.WriteLine($"No of Days: {leaveRequest.NoOfDays}");
            //    Console.WriteLine($"Status: {leaveRequest.Status}");
            //    Console.WriteLine("--------------------------------------------------------");
            //}
            Console.WriteLine(holidayCount+"hiiiiiiiii");
            var monthName = DateTime.Now.ToString("MMMM");
            ViewBag.employee = emp;
            ViewBag.leave = leaves;
            ViewBag.dept = dept;
            ViewBag.leavemonth= holidayCount;
            ViewBag.month = monthName;
            return View();
        }
    }
}
