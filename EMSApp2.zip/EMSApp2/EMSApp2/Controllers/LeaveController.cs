﻿using System.Runtime.CompilerServices;
using EMSApp2.Data;
using EMSApp2.Models.EMS;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using EMSApp2.Models;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using Microsoft.AspNetCore.Authorization;

namespace EMSApp2.Controllers
{

    [Authorize]
    public class LeaveController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly UserManager<User> _userManager;

        public LeaveController(ApplicationDbContext context, UserManager<User> userManager)
        {
            _context = context;
            _userManager = userManager;
        }
        [Authorize(Roles = "Employee")]
        public IActionResult Apply()
        {
            //Console.WriteLine("hih apply without anuthinge");
            return View();
        }
        [Authorize(Roles = "Employee")]
        [HttpPost]
        public async Task<IActionResult> Apply(LeaveRequestViewModel model)
        {

            if (ModelState.IsValid)
            {
                if(model.StartDate< DateTime.Today || model.EndDate< DateTime.Today)
                {
                    ModelState.AddModelError("StartDate", "The start date or end date cannot be in the past.");
                    return View(model);

                }
               

                var employee = await _context.Employees.FirstOrDefaultAsync(e => e.Email == User.Identity.Name);

                int WorkingDaysCount = GetCount(model.StartDate,model.EndDate);
               // Console.WriteLine("Working days count"+ WorkingDaysCount);
               if(WorkingDaysCount > employee.LeaveDays)
                {
                    ModelState.AddModelError("EndDate","You dont have enough Leaves left to apply");
                    return View(model);

                }

                var leaverequest = new LeaveRequest
                {
                    StartDate = model.StartDate,
                    EndDate = model.EndDate,
                    Reason = model.Reason,
                    NoOfDays = WorkingDaysCount,
                    Status = "Pending",
                    EmployeeId = employee.EmployeeId,
                    
                    CreatedAt = DateTime.Now,
                    ApproversCmnt = ""




                };

                _context.LeaveRequests.Add(leaverequest);
                var days = employee.LeaveDays;
               

                await _context.SaveChangesAsync();
                

            }
            else
            {
                foreach (var error in ModelState.Values.SelectMany(v => v.Errors))
                {
                    Console.WriteLine(error.ErrorMessage);
                }
               
            }

            return RedirectToAction("DashBoard","Home");

        }
        private int GetCount(DateTime s, DateTime e)
        {
            int count = 0;
            Console.WriteLine($"{s.Date} , {e.Date}");
           
            if(s.Date == e.Date)
            {
                Console.WriteLine("this block is working");
                count = 1;
                return count;
            }
            Console.WriteLine("the block isnt working!");

            for(var date = s.Date;date <=e.Date;date = date.AddDays(1))
            {
                if(date.DayOfWeek != DayOfWeek.Saturday && date.DayOfWeek != DayOfWeek.Sunday)
                {
                    Console.WriteLine(date);
                    Console.WriteLine(date.DayOfWeek);
                    Console.WriteLine(count);
                    count++;
                } 
            }
          //  Console.WriteLine(count);
            return count;
        }
        [Authorize(Roles = "Admin,Manager")]
        [HttpGet]
        public async Task<IActionResult> Index()
        {
            var user = await _userManager.FindByEmailAsync(User.Identity.Name);
            var role = await _userManager.GetRolesAsync(user);

            if (role.Contains("Admin"))
            {
                var leaveRequests = _context.LeaveRequests.Where(l => l.Status == "Pending")
                           .Include(l => l.Employee)  // Include Employee data
                           .ToList();
                return View(leaveRequests);

            }
            else
            {
                var emp = await _context.Employees.FirstOrDefaultAsync(e => e.Email == User.Identity.Name);
                var manager = await _context.Managers
                           .FirstOrDefaultAsync(m => m.ManagerId == emp.EmployeeId);

                var employeesInDepartment = await _context.Employees
                            .Where(e => e.DepartmentId == manager.DepartmentId)  // Find employees who belong to the same department
                            .ToListAsync();

                var leaveRequests = await _context.LeaveRequests
                        .Where(l => l.Status == "Pending")  // Filter leave requests for employees in the department
                        .Include(l => l.Employee)  // Include Employee data if needed
                        .ToListAsync();
                leaveRequests = leaveRequests.Where(l => employeesInDepartment
                                              .Any(e => e.EmployeeId == l.EmployeeId))
                                 .ToList();
                //var leaveRequests = _context.LeaveRequests.Where(l => l.Status == "Pending")
                //           .Include(l => l.Employee)  // Include Employee data
                //           .ToList();
                return View(leaveRequests);

            }



        }

        [Authorize(Roles = "Admin,Manager")]
        [HttpGet]
        public async Task<IActionResult> LeaveHistory()
        {
            var leaveRequests = _context.LeaveRequests
                            .Include(l => l.Employee)  // Include Employee data
                            .ToList();

            return View(leaveRequests);
        }
        [Authorize(Roles = "Admin,Manager")]
        [HttpGet]
        public async Task<IActionResult> Details(int id)
        {
          
            var leaveRequests = await _context.LeaveRequests
                             .Include(l => l.Employee).FirstOrDefaultAsync(e=> e.Id == id); // Include Employee data
                           
            //Console.WriteLine(leaveRequests);
            return View(leaveRequests);
           // return View();
        }
        [Authorize(Roles = "Admin,Manager")]
        [HttpPost]
        public async Task<IActionResult> UpdateStatus(LeaveRequest model ,int id, string status)
        {

            var leaveRequests = await _context.LeaveRequests
                            .FirstOrDefaultAsync(l => l.Id == id); // Include Employee data
            if(leaveRequests != null)
            {
                //Console.WriteLine("this is for checking " + ab +"enfing");
                leaveRequests.Status = status;
                leaveRequests.ApproversCmnt = model.ApproversCmnt;
                

              
            }
            if(status=="Approved")
            {
               var emp= await _context.Employees.FirstOrDefaultAsync(e => e.EmployeeId == leaveRequests.EmployeeId);
                int c = emp.LeaveDays;
                emp.LeaveDays = c - leaveRequests.NoOfDays;

            }
            await _context.SaveChangesAsync();

            return RedirectToAction("Index","Leave");
            // return View();
        }

        [Authorize(Roles = "Employee")]
        [HttpGet]
        public async Task<IActionResult> ViewStatus()
        {
            var employee = await _context.Employees.FirstOrDefaultAsync(e => e.Email == User.Identity.Name);


            var leaveRequests =  _context.LeaveRequests.Where(l => l.Status != "Pending" &&  l.EmployeeId == employee.EmployeeId).ToList();
           return View(leaveRequests);
        }
        [HttpGet]
        public async Task<IActionResult> History()
        {
            var employee = await _context.Employees.FirstOrDefaultAsync(e => e.Email == User.Identity.Name);

            var leaveRequests = _context.LeaveRequests.Where(l => l.Status == "Pending" && l.EmployeeId == employee.EmployeeId);

            return View(leaveRequests);
        }
        
        [HttpPost]
        public async Task<IActionResult> Revoke(int id)
        {
            var leaveRequest = await _context.LeaveRequests.FirstOrDefaultAsync(l => l.Id == id);
            if (leaveRequest != null)
            {
                _context.LeaveRequests.Remove(leaveRequest);
                _context.SaveChangesAsync();
            }
            return RedirectToAction("History","Leave");
        }
    }
}
