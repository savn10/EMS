﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using EMSApp2.Data;
using EMSApp2.Models.EMS;
using Microsoft.AspNetCore.Identity;
using EMSApp2.Models;
using Microsoft.AspNetCore.Authorization;

namespace EMSApp2.Controllers
{
    [Authorize(Roles = "Admin")]
    public class ManagersController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly UserManager<User> _userManager;
        

        

        public ManagersController(ApplicationDbContext context, UserManager<User> userManager) 
        {
            _context = context;
            _userManager = userManager;
        }

        // GET: Managers
        public async Task<IActionResult> Index()
        {
            var applicationDbContext = _context.Managers.Include(m => m.Department).Include(m => m.ManagerEmployee);
            return View(await applicationDbContext.ToListAsync());
        }

        // GET: Managers/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var manager = await _context.Managers
                .Include(m => m.Department)
                .Include(m => m.ManagerEmployee)
                .FirstOrDefaultAsync(m => m.ManagerId == id);
            if (manager == null)
            {
                return NotFound();
            }

            return View(manager);
        }

        
        // GET: Managers/Create
        public IActionResult Create()
        {
            var departmentsWithoutManagers = _context.Departments
                  .Where(d => !_context.Managers.Any(m => m.DepartmentId == d.DepartmentId))
                  .ToList();
            var employeesNotManagers = _context.Employees
              .Where(e => !_context.Managers.Any(m => m.ManagerId == e.EmployeeId))
              .ToList();
            //if (selectedManagerId.HasValue)
            //{
            //    // Get the selected manager's department
            //    var manager = _context.Employees.FirstOrDefault(e => e.EmployeeId == selectedManagerId.Value);
            //    if (manager != null)
            //    {
            //        // Filter departments to only show the selected manager's department
            //        departmentsWithoutManagers = departmentsWithoutManagers
            //            .Where(d => d.DepartmentId == manager.DepartmentId)
            //            .ToList();
            //    }
            //}

            ViewData["DepartmentId"] = new SelectList(departmentsWithoutManagers, "DepartmentId", "DepartmentId");
            ViewData["ManagerId"] = new SelectList(employeesNotManagers, "EmployeeId", "EmployeeId");
            return View();
        }

        // POST: Managers/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        
        
        
        
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("ManagerId")] Manager manager)
        {
            if (ModelState.IsValid)
            {
                var emp = await _context.Employees.FirstOrDefaultAsync(e => e.EmployeeId == manager.ManagerId);

                manager.DepartmentId = emp.DepartmentId;

                var Dept = await _context.Departments.FirstOrDefaultAsync(d => d.DepartmentId == emp.DepartmentId);

               


                _context.Add(manager);
                await _context.SaveChangesAsync();


                var user = await _userManager.FindByEmailAsync(User.Identity.Name);
                emp.Role = "Manager";


                var roles = await _userManager.GetRolesAsync(user);
                if (roles.Contains("Employee"))
                {
                    await _userManager.RemoveFromRoleAsync(user, "Employee");
                    await _userManager.AddToRoleAsync(user, "Manager");
                }

                await _context.SaveChangesAsync();
                Console.WriteLine(_userManager.GetRolesAsync(user));

                return View();
            }
            var departmentsWithoutManagers = _context.Departments
                 .Where(d => !_context.Managers.Any(m => m.DepartmentId == d.DepartmentId))
                 .ToList();
            var employeesNotManagers = _context.Employees
              .Where(e => !_context.Managers.Any(m => m.ManagerId == e.EmployeeId))
              .ToList();

            ViewData["DepartmentId"] = new SelectList(departmentsWithoutManagers, "DepartmentId", "DepartmentId", manager.DepartmentId);
            ViewData["ManagerId"] = new SelectList(employeesNotManagers, "EmployeeId", "EmployeeId", manager.ManagerId);
            return View(manager);
        }

       

        // GET: Managers/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var manager = await _context.Managers.FindAsync(id);
            if (manager == null)
            {
                return NotFound();
            }
            ViewData["DepartmentId"] = new SelectList(_context.Departments, "DepartmentId", "DepartmentId", manager.DepartmentId);
            ViewData["ManagerId"] = new SelectList(_context.Employees, "EmployeeId", "EmployeeId", manager.ManagerId);
            return View(manager);
        }

        // POST: Managers/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("ManagerId,DepartmentId")] Manager manager)
        {
            if (id != manager.ManagerId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {

                try
                {
                    _context.Update(manager);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ManagerExists(manager.ManagerId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            var departmentsWithoutManagers = _context.Departments
               .Where(d => !_context.Managers.Any(m => m.DepartmentId == d.DepartmentId))
               .ToList();
            var employeesNotManagers = _context.Employees
              .Where(e => !_context.Managers.Any(m => m.ManagerId == e.EmployeeId))
              .ToList();

            ViewData["DepartmentId"] = new SelectList(departmentsWithoutManagers, "DepartmentId", "DepartmentId", manager.DepartmentId);
            ViewData["ManagerId"] = new SelectList(employeesNotManagers, "EmployeeId", "EmployeeId", manager.ManagerId);
            return View(manager);
        }

        // GET: Managers/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var manager = await _context.Managers
                .Include(m => m.Department)
                .Include(m => m.ManagerEmployee)
                .FirstOrDefaultAsync(m => m.ManagerId == id);
            if (manager == null)
            {
                return NotFound();
            }

            return View(manager);
        }

        // POST: Managers/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var manager = await _context.Managers.FindAsync(id);
            if (manager != null)
            {
                _context.Managers.Remove(manager);

                var emp = await _context.Employees.FirstOrDefaultAsync(e=>e.EmployeeId==id);

                emp.Role = "Employee";
                var user = await _userManager.FindByEmailAsync(User.Identity.Name);
                Console.WriteLine();
                Console.WriteLine(await _userManager.IsInRoleAsync(user, "Manager"));
                

                if(await _userManager.IsInRoleAsync(user,"Manager"))
                {
                    Console.WriteLine("this is executed");
                    await _userManager.RemoveFromRoleAsync(user,"Manager");
                    await _userManager.AddToRoleAsync(user, "Employee");

                    var roles = await _userManager.GetRolesAsync(user);
                    string rolesString = string.Join(", ", roles);
                    Console.WriteLine("Manager delete block " + rolesString);
                }
                Console.WriteLine("manager delete block didnt execute");

            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool ManagerExists(int id)
        {
            return _context.Managers.Any(e => e.ManagerId == id);
        }
    }
}
