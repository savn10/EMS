﻿using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using EMSApp2.Models;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using EMSApp2.Models.EMS;
using Microsoft.SqlServer;
using Microsoft.EntityFrameworkCore.SqlServer;
using System.Reflection.Emit;
using System.Collections.Generic;


namespace EMSApp2.Data
{
    public class ApplicationDbContext : IdentityDbContext<User>
    {


        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {


        }
        public DbSet<Employee> Employees { get; set; }
        public DbSet<Department> Departments { get; set; }
        public DbSet<Manager> Managers { get; set; }

        public DbSet<LeaveRequest> LeaveRequests { get; set; }

        public DbSet<UserHistory> UserHistories { get; set; }
        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);

            // EmployeeId as Primary Key
            builder.HasSequence<int>("EmployeeIdSequence", schema: "dbo")
                    .StartsAt(1010) // You can specify the starting number
                    .IncrementsBy(1); // Specify how the number increments, by 1 in this case

            builder.Entity<Employee>()
                .Property(e => e.EmployeeId)
                .HasDefaultValueSql("NEXT VALUE FOR dbo.EmployeeIdSequence");
            builder.Entity<Employee>()
                .HasIndex( e => e.Email).IsUnique();

            builder.Entity<Department>()
               .Property(d => d.DepartmentId)
               .ValueGeneratedNever();



            builder.Entity<Manager>()
               .HasOne(m => m.ManagerEmployee)  // Manager has one Employee (the Employee acting as Manager)
               .WithOne()  // Each Employee can only be the manager of one department
               .HasForeignKey<Manager>(m => m.ManagerId)  // Foreign Key is ManagerId in Manager table (references EmployeeId)
               .OnDelete(DeleteBehavior.Restrict);

            builder.Entity<Manager>()
                .HasOne(m => m.Department)  // Manager has one Department
                .WithOne()  // Each Department can have only one Manager
                .HasForeignKey<Manager>(m => m.DepartmentId)  // Foreign Key is DepartmentId in Manager
                .OnDelete(DeleteBehavior.Restrict);
           
            builder.Entity<LeaveRequest>()
               .HasOne(l => l.Employee)         // A LeaveRequest is associated with one Employee
               .WithMany(e => e.LeaveRequest)  // An Employee can have many LeaveRequests
               .HasForeignKey(l => l.EmployeeId)
               .OnDelete(DeleteBehavior.Cascade);

        





        }
    }
}
