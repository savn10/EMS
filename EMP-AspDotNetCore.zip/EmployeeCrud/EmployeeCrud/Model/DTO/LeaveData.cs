﻿using System.ComponentModel.DataAnnotations;

namespace EmployeeCrud.Model.DTO
{
    public class LeaveData
    {
        public string UserEmail { get; set; }
        [Required]
        [DataType(DataType.Date)]
      
        public DateTime StartDate { get; set; }

        [Required]
        [DataType(DataType.Date)]
        public DateTime EndDate { get; set; }

        [Required]
        [StringLength(250)]
        public string Reason { get; set; }
    }
}
