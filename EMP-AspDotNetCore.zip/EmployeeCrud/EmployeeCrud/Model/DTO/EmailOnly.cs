﻿namespace EmployeeCrud.Model.DTO
{
    public class EmailOnly
    {
        public required string Email { get; set; }
    }
}
