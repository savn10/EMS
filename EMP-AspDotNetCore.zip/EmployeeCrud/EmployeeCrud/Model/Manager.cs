﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace EmployeeCrud.Model
{
    public class Manager
    {
        [Key]
        public int ManagerId { get; set; }  
        public int DepartmentId { get; set; }
        [ForeignKey("ManagerId")]
        public Employee1? ManagerEmployee { get; set; }
        public Department? Department { get; set; }



    }
}

