﻿using System.ComponentModel.DataAnnotations;

namespace EmployeeCrud.Model
{
    public class Department
    {
        public int DepartmentId { get; set; }
       
        [StringLength(30)]
        public string DepartmentName { get; set; }

        public ICollection<Employee1>? Employees { get; set; }
    }
}
