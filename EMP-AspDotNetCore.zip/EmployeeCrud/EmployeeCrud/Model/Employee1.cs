﻿using System.ComponentModel.DataAnnotations;

namespace EmployeeCrud.Model
{
    public class Employee1
    {
        [Key]
        [Required]

        public int EmployeeId { get; set; }
      
        [Required(ErrorMessage = "Name is required")]
        [StringLength(30)]
        public string EmployeeName { get; set; }

        public string? Gender { get; set; }
        [Required(ErrorMessage = "Email is required")]
        [EmailAddress]

        public string Email { get; set; }

        [StringLength(13, MinimumLength = 10, ErrorMessage = "Atleast 10 characters")]
        [Required(ErrorMessage = "phone number is req")]
        public string? PhoneNumber { get; set; }

        [Required(ErrorMessage = "Role is req")]
        public string Role { get; set; }

        public DateOnly HireDate { get; set; }

        public int DepartmentId { get; set; }

        public int LeaveDays { get; set; }
        
       



    }
}
