﻿namespace EmployeeCrud.Model
{
    public class UpdateLeave
    {
        public int id { get; set; }

        public string Approverscmnt { get; set; }

        public string status{ get; set; }
    }
}
