﻿
using Microsoft.AspNetCore.Identity;

namespace EmployeeCrud.Model
{
    public class Seed
    {

        public static async Task Initialize(IServiceProvider serviceProvider, UserManager<User> userManager, RoleManager<IdentityRole> roleManager)
        {
            var roleNames = new[] { "Admin", "Manager", "Employee" };

            foreach (var roleName in roleNames)
            {
                var roleExist = await roleManager.RoleExistsAsync(roleName);
                if (!roleExist)
                {
                    await roleManager.CreateAsync(new IdentityRole(roleName));  // Create roles
                }
            }

            // Create Admin user
            var adminUser = await userManager.FindByEmailAsync("admin@admin.com");
            if (adminUser == null)
            {
                adminUser = new User
                {
                    UserName = "admin@admin.com",
                    Email = "admin@admin.com"
                };
                await userManager.CreateAsync(adminUser, "AdminPassword123!");
                await userManager.AddToRoleAsync(adminUser, "Admin");
            }

            // Create Manager user
            var managerUser = await userManager.FindByEmailAsync("manager@manager.com");
            if (managerUser == null)
            {
                managerUser = new User
                {
                    UserName = "manager@manager.com",
                    Email = "manager@manager.com"
                };
                await userManager.CreateAsync(managerUser, "ManagerPassword123!");
                await userManager.AddToRoleAsync(managerUser, "Manager");
            }

            // Create Employee user
            var employeeUser = await userManager.FindByEmailAsync("employee@employee.com");
            if (employeeUser == null)
            {
                employeeUser = new User
                {
                    UserName = "employee@employee.com",
                    Email = "employee@employee.com"
                };
                await userManager.CreateAsync(employeeUser, "EmployeePassword123!");
                await userManager.AddToRoleAsync(employeeUser, "Employee");
            }
        }
    }
}
