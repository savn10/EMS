﻿using Microsoft.AspNetCore.Identity;

namespace EmployeeCrud.Model
{
    public class User :IdentityUser
    {

    }
}
