using System.Text;
using EmployeeCrud.Data;
using EmployeeCrud.Model;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc.Authorization;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowReactApp", policy =>
    {
        policy.WithOrigins("http://localhost:5174")  // React frontend URL
              .AllowAnyHeader()
              .AllowAnyMethod().AllowCredentials(); ;
    });
});


builder.Configuration.AddJsonFile("appsettings.json", optional: false, reloadOnChange: true);



builder.Services.AddDbContext<ApplicationDbContext>(options => options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

builder.Services.AddIdentity<User, IdentityRole>(Options =>
{
    Options.Password.RequireNonAlphanumeric = false;
    Options.Password.RequireUppercase = false;

    Options.Password.RequiredLength = 6;
    Options.Password.RequireUppercase = false;
    Options.User.RequireUniqueEmail = true;
    Options.SignIn.RequireConfirmedAccount = false;



})
    .AddEntityFrameworkStores<ApplicationDbContext>()
    .AddDefaultTokenProviders()
   ; // If you want, customize cookie settings here but won't be used directly.


builder.Services.ConfigureApplicationCookie(options =>
{
    // We are not using cookies for authentication, so we can leave it empty or disable it
    options.Cookie.SameSite = SameSiteMode.Strict; // You can customize cookie settings here if you need to, but cookies won't be used.
    options.Cookie.HttpOnly = true;
    options.ExpireTimeSpan = TimeSpan.Zero; // Disable cookies entirely
});

// JWT Authentication Configuration
var key = builder.Configuration["Jwt:Key"]!;
if (string.IsNullOrEmpty(key))
{
    throw new InvalidOperationException("Jwt:Key configuration is missing.");
}
var issuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(key));


builder.Services.AddAuthentication(options =>{ options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;})
   .AddJwtBearer(
    options =>
   {
       options.RequireHttpsMetadata = false;
       options.SaveToken = true;
       options.TokenValidationParameters = new TokenValidationParameters
       {
           ValidateIssuer = true,
           ValidateAudience = true,
           ValidateLifetime = true,
           ValidateIssuerSigningKey = true,
           IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(key)),
           ValidIssuer = builder.Configuration["Jwt:Issuer"],
           ValidAudience = builder.Configuration["Jwt:Audience"]
       };

       options.Events = new JwtBearerEvents
       {
           OnAuthenticationFailed = context =>
           {
               Console.WriteLine("Authentication failed: " + context.Exception.Message);
               return Task.CompletedTask;
           },
           OnChallenge = context =>
           {
               context.Response.StatusCode = 401; // Unauthorized
               context.Response.ContentType = "application/json";
               return context.Response.WriteAsync("{\"error\": \"Unauthorized\"}");
           }
       };
   }
);



builder.Services.AddAuthorization();
// Add controllers and Swagger services
builder.Services.AddControllers(
//    options =>
//{
//    options.Filters.Add(new AuthorizeFilter()); // Force authorization globally
//}
);
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    // Add a security definition for Authorization header (Bearer token)
    c.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
    {
        In = ParameterLocation.Header,
        Description = "Please enter JWT with Bearer into field",
        Name = "Authorization",
        Type = SecuritySchemeType.ApiKey
    });

    c.AddSecurityRequirement(new OpenApiSecurityRequirement
    {
        {
            new OpenApiSecurityScheme
            {
                Reference = new OpenApiReference
                {
                    Type = ReferenceType.SecurityScheme,
                    Id = "Bearer"
                }
            },
            new string[] { }
        }
    });
});

var app = builder.Build();

// Use middleware
app.UseCors("AllowReactApp");

// Configure HTTP request pipeline
if (app.Environment.IsDevelopment())
{
    app.UseDeveloperExceptionPage();
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseAuthentication();
app.UseHttpsRedirection();
app.UseAuthorization();

app.MapControllers();

using (var scope = app.Services.CreateScope())
{
    var services = scope.ServiceProvider;
    var userManager = services.GetRequiredService<UserManager<User>>();
    var roleManager = services.GetRequiredService<RoleManager<IdentityRole>>();
    await Seed.Initialize(services, userManager, roleManager);
}


app.Run();
