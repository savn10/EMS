﻿public class LogHeadersMiddleware
{
    private readonly RequestDelegate _next;

    public LogHeadersMiddleware(RequestDelegate next)
    {
        _next = next;
    }

    public async Task InvokeAsync(HttpContext httpContext)
    {
        // Log all headers for debugging
        foreach (var header in httpContext.Request.Headers)
        {
            Console.WriteLine($"{header.Key}: {header.Value}");
        }

        // Call the next middleware in the pipeline
        await _next(httpContext);
    }
}
