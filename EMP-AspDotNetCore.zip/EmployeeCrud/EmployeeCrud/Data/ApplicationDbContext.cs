﻿using EmployeeCrud.Model;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace EmployeeCrud.Data
{
    public class ApplicationDbContext : IdentityDbContext<User>
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {
        }
           
        public DbSet<Employee1> Employee { get; set; }
        public DbSet<Department>Departments { get; set; }
        public DbSet<Manager>Managers { get; set; }
        public DbSet<LeaveRequest> LeaveRequests { get; set; }


        protected override void OnModelCreating(ModelBuilder builder)
            {
                base.OnModelCreating(builder);
            builder.HasSequence<int>("EmployeeIdSequence", schema: "dbo")
                    .StartsAt(1010) // You can specify the starting number
                    .IncrementsBy(1); // Specify how the number increments, by 1 in this case
            builder.Entity<Employee1>()
               .Property(e => e.EmployeeId)
               .HasDefaultValueSql("NEXT VALUE FOR dbo.EmployeeIdSequence");

            builder.HasSequence<int>("DepartmentIdSequence", schema: "dbo")
                           .StartsAt(10) // You can specify the starting number
                           .IncrementsBy(1);
            builder.Entity<Department>()
               .Property(e => e.DepartmentId)
               .HasDefaultValueSql("NEXT VALUE FOR dbo.DepartmentIdSequence");

            builder.Entity<Manager>()
                 .HasOne(m => m.Department)  // Manager has one Department
                 .WithOne()  // Each Department can have only one Manager
                 .HasForeignKey<Manager>(m => m.DepartmentId)  // Foreign Key is DepartmentId in Manager
                 .OnDelete(DeleteBehavior.Restrict);
           
           


        }

    }

}
