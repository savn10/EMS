﻿using System.Data;
using EmployeeCrud.Data;
using EmployeeCrud.Model;
using EmployeeCrud.Model.DTO;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace EmployeeCrud.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
   // [Authorize]
  


    public class EmployeeController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly UserManager<User> _userManager;

        public EmployeeController(ApplicationDbContext context, UserManager<User> userManager)
        {
            _context = context;
            _userManager = userManager;
        }

        //[HttpGet]
        //public IActionResult Index()
        //{
        //    return View();
        //}

       
        //public async Task <IActionResult> Create([FromBody] Employee emp)
        //{
        //    if (emp == null)
        //    {
        //        return BadRequest("Employee data is required.");
        //    }

        //    _context.Employees.Add(emp);
            

        //    var empl = await _context.Employees.ToListAsync();
        //    await _context.SaveChangesAsync();
        //    return Ok(empl);
        //}

        [HttpPost("Index")]
        //[Authorize]
        [Authorize(Roles = "Admin,Manager")]
        public async Task<ActionResult<IEnumerable<Employee1>>>Index(EmailOnly model)
        {
            var user = await _userManager.FindByEmailAsync(model.Email);
            var role = await _userManager.GetRolesAsync(user);
            var dept = await _context.Employee.FirstOrDefaultAsync(e => e.Email == model.Email);
            if (dept.Role == "Admin")
            {
              
                return Ok(await _context.Employee.ToListAsync());

            }
            else
            {
               
                var applicationDbContext = _context.Employee.Where(e => e.DepartmentId == dept.DepartmentId);
                return Ok(await applicationDbContext.ToListAsync());
            }


           


            

            
        }

        [HttpPost("Create")]
        [Authorize(Roles = "Admin")]

        public async Task<IActionResult> Create([FromBody] Employee1 emp)
        {
            if (emp == null)
            {
                return BadRequest("Employee data is required.");
            }

            _context.Employee.Add(emp);
            await _context.SaveChangesAsync();

            var empl = await _context.Employee.ToListAsync();
            await _context.SaveChangesAsync();
            return Ok();
        }

        [HttpGet("CheckEmail/{Email}")]
        public  bool  EmailExists(string Email)
        {
            return _context.Employee.Any(e => e.Email == Email);
        }

        [HttpDelete("Delete/{EmployeeId}")]
        public async Task<IActionResult> Delete(int EmployeeId)
        {
            var employee = await _context.Employee.FindAsync(EmployeeId);
            if (employee != null)
            {
                _context.Employee.Remove(employee);
            }

            await _context.SaveChangesAsync();
            return Ok();
        }

        [HttpPost("dashboard")]
        [Authorize(Roles = "Admin,Manager,Employee")]
        public async Task<IActionResult> Dashboard(EmailOnly model)
        {
            var employee = await _context.Employee.FirstOrDefaultAsync(e => e.Email == model.Email);
            var manager = await _context.Managers.FirstOrDefaultAsync(e => e.DepartmentId == employee.DepartmentId);

            if(manager!=null)
            {
                var dept = await _context.Departments.FirstOrDefaultAsync(d => d.DepartmentId == manager.DepartmentId);

                var managerName = await _context.Employee.FirstOrDefaultAsync(e => e.EmployeeId == manager.ManagerId);



                var data = new dashboard
                {
                    EmployeeId = employee.EmployeeId,

                    EmployeeName = employee.EmployeeName,

                    Email = employee.Email,

                    Role = employee.Role,
                    LeaveDays = employee.LeaveDays,



                    DepartmentName = dept.DepartmentName,
                    ManagerName = managerName.EmployeeName

                };
                return Ok(data);
            }
            else
            {
                var dept = await _context.Departments.FirstOrDefaultAsync(d => d.DepartmentId == employee.DepartmentId);

                var data = new dashboard
                {
                    EmployeeId = employee.EmployeeId,

                    EmployeeName = employee.EmployeeName,

                    Email = employee.Email,

                    Role = employee.Role,
                    LeaveDays = employee.LeaveDays,



                    DepartmentName = dept.DepartmentName,
                    ManagerName = "No Manager has been Assigned"

                };
                return Ok(data);

            }
            

            

        }



    }

}
