﻿using System.Data;
using System.IdentityModel.Tokens.Jwt;
using EmployeeCrud.Data;
using EmployeeCrud.Model;
using EmployeeCrud.Model.DTO;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
//using Microsoft.IdentityModel.JsonWebTokens;

namespace EmployeeCrud.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    
    public class LeaveController : ControllerBase
    {
        private readonly ApplicationDbContext _context;
        private readonly UserManager<User> _userManager;

        public LeaveController(ApplicationDbContext context, UserManager<User> userManager)
        {
            _context = context;
            _userManager = userManager;
        }
        [HttpPost("Apply")]
        [Authorize(Roles = "Employee")]
        public async Task<IActionResult> Apply([FromBody] LeaveData leave)
        {
          

            var employee = await _context.Employee.FirstOrDefaultAsync(e => e.Email == leave.UserEmail);
           

            if (employee == null) {
                return BadRequest("User is not Identified");
            }
            int WorkingDaysCount = GetCount(leave.StartDate, leave.EndDate);
            var leaverequest = new LeaveRequest
            {
                StartDate = leave.StartDate,
                EndDate = leave.EndDate,
                Reason = leave.Reason,
                NoOfDays = WorkingDaysCount,
                Status = "Pending",
                EmployeeId = employee.EmployeeId,

                CreatedAt = DateTime.Now,
                ApproversCmnt = ""

            };
            _context.LeaveRequests.Add(leaverequest);
            var remainingLeave = employee.LeaveDays - WorkingDaysCount;
            employee.LeaveDays = remainingLeave;

            await _context.SaveChangesAsync();

            return Ok();



        }
        private int GetCount(DateTime s, DateTime e)
        {
            int count = 0;
            //Console.WriteLine($"{s.Date} , {e.Date}");

            if (s.Date == e.Date)
            {
                Console.WriteLine("this block is working");
                count = 1;
                return count;
            }
           // Console.WriteLine("the block isnt working!");

            for (var date = s.Date; date <= e.Date; date = date.AddDays(1))
            {
                if (date.DayOfWeek != DayOfWeek.Saturday && date.DayOfWeek != DayOfWeek.Sunday)
                {
                   
                    count++;
                }
            }
            //  Console.WriteLine(count);
            return count;
        }

        [HttpPost("Index")]
        [Authorize(Roles = "Admin,Manager")]
        public async Task<ActionResult<IEnumerable<LeaveRequest>>> Index([FromBody] EmailOnly model)
        {
            var user = await _userManager.FindByEmailAsync(model.Email);
            var role = await _userManager.GetRolesAsync(user);

            if (role.Contains("Admin"))
            {
                var leaveRequests = _context.LeaveRequests.Where(l => l.Status == "Pending")
                           .Include(l => l.Employee)  // Include Employee data
                           .ToList();
                return Ok(leaveRequests);

            }
            else
            {
                var emp = await _context.Employee.FirstOrDefaultAsync(e => e.Email == model.Email);
                var manager = await _context.Managers
                           .FirstOrDefaultAsync(m => m.ManagerId == emp.EmployeeId);

                var employeesInDepartment = await _context.Employee
                            .Where(e => e.DepartmentId == manager.DepartmentId)  // Find employees who belong to the same department
                            .ToListAsync();

                var leaveRequests = await _context.LeaveRequests
                        .Where(l => l.Status == "Pending")  // Filter leave requests for employees in the department
                        .Include(l => l.Employee)  // Include Employee data if needed
                        .ToListAsync();
                leaveRequests = leaveRequests.Where(l => employeesInDepartment
                                              .Any(e => e.EmployeeId == l.EmployeeId))
                                 .ToList();

                return Ok(leaveRequests);

            }
        }
        [HttpPost("Details/{id}")]
        [Authorize(Roles = "Admin,Manager")]
        public async Task<IActionResult> Details(int id)
        {

            var leaveRequests = await _context.LeaveRequests
                             .Include(l => l.Employee).FirstOrDefaultAsync(e => e.Id == id); // Include Employee data

            //Console.WriteLine(leaveRequests);
            return Ok   (leaveRequests);
            // return View();
        }
        [HttpPost("Update")]
        [HttpGet("Details/{id}")]
        [Authorize(Roles = "Admin,Manager")]
        public async Task<IActionResult> UpdateStatus(UpdateLeave model)
        {

            var leaveRequests = await _context.LeaveRequests
                            .FirstOrDefaultAsync(l => l.Id == model.id); // Include Employee data
            if (leaveRequests != null)
            {
                //Console.WriteLine("this is for checking " + ab +"enfing");
                leaveRequests.Status = model.status;
                leaveRequests.ApproversCmnt = model.Approverscmnt;



            }
            if (model.status == "Approved")
            {
                var emp = await _context.Employee.FirstOrDefaultAsync(e => e.EmployeeId == leaveRequests.EmployeeId);
                int c = emp.LeaveDays;
                emp.LeaveDays = c - leaveRequests.NoOfDays;

            }
            await _context.SaveChangesAsync();

            return Ok();
            // return View();
        }
        [Authorize(Roles = "Employee")]
        [HttpPost("ViewStatus")]
        public async Task<IActionResult> ViewStatus(EmailOnly model)
        {
            var employee = await _context.Employee.FirstOrDefaultAsync(e => e.Email == model.Email);


            var leaveRequests = _context.LeaveRequests.Where(l => l.Status != "Pending" && l.EmployeeId == employee.EmployeeId).ToList();
            return Ok(leaveRequests);
        }

    }
}
