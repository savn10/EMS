﻿using System;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using EmployeeCrud.Data;
using EmployeeCrud.Model;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using Microsoft.VisualStudio.Web.CodeGenerators.Mvc.Templates.BlazorIdentity.Pages.Manage;
using NuGet.Protocol;

namespace EmployeeCrud.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AuthController : ControllerBase
    {
        private readonly UserManager<User> _userManager;
        private readonly SignInManager<User> _signInManager;
        private readonly IConfiguration _configuration;
        private readonly ApplicationDbContext _context;

        public AuthController(UserManager<User> userManager, SignInManager<User> signInManager, IConfiguration configuration, ApplicationDbContext context)
        {
            _userManager = userManager;
            _signInManager = signInManager;
            _configuration = configuration;
            _context = context;
        }
        //[HttpPost("register")]
        //public async Task<IActionResult> Register([FromBody] RegisterModel model)
        //{
        //    if (ModelState.IsValid)
        //    {
        //        var user = new User { UserName = model.Email, Email = model.Email };
        //        var result = await _userManager.CreateAsync(user, model.Password);


        //        if (result.Succeeded)
        //        {

        //            var emp = await _context.Employee.FirstOrDefaultAsync(e=>e.Email == model.Email);
        //            if (emp != null)
        //            {
        //                var role = emp.Role;
        //                await _userManager.AddToRoleAsync(user, role);

        //            }
        //            // Assign default role "User"
                   

        //           // var token = GenerateJwtToken(user);
        //            return Ok();
        //        }

        //        return BadRequest(result.Errors);
        //    }

        //    return BadRequest("Invalid model.");
        //}

        [HttpPost("login")]

        public async Task<IActionResult> Login([FromBody] LoginModel model)
        {
           
                var user = await _userManager.FindByEmailAsync(model.Email);
                if (user != null)
                {
                var emp = await _context.Employee.FirstOrDefaultAsync(e => e.Email == model.Email);
                var result = await _signInManager.PasswordSignInAsync(user, model.Password, isPersistent: false, lockoutOnFailure: false);
                   var roles = await _userManager.GetRolesAsync(user);
                Console.WriteLine("thisis the roles part");
                if (roles.Count == 0)
                {
                    // Print each role
                    var role1 = emp.Role;
                    await _userManager.AddToRoleAsync(user, role1);

                }
                else
                {
                    foreach (var role2 in roles)
                    {
                        Console.WriteLine($"Role: {role2}");
                    }
                }

               

                if(roles == null)
                {
                    string role1 = emp.Role;
                    await _userManager.AddToRoleAsync(user, role1);
                    Console.WriteLine("Role has been added!");
                }
                foreach(var r in roles )
                {
                    Console.WriteLine(r + "cw");
                }

                    
                    string role;
                    if (roles.Contains("Admin"))
                    {
                        role = "Admin";
                    }
                    else if (roles.Contains("Manager"))
                    {
                        role = "Manager";

                    }
                    else {
                        role = "Employee";
                    }

                    if (result.Succeeded)
                    {
                        var token = GenerateJwtToken(user, role);
                        return Ok(new
                        {
                            Token = token,
                            UserDetails = new
                            {
                                model.Email, // Assuming user has a 'Name' property
                                emp.EmployeeName,
                                emp.Role
                            }
                        });

                        //return Ok();
                    }
                }
                Console.WriteLine("Invalid login attempt.");
                return Unauthorized("Invalid login attempt.");

        }
        


        private  string GenerateJwtToken(User user,string role)
        {
            
            var claims = new[]
            {
            new Claim(JwtRegisteredClaimNames.Sub, user.Id.ToString()),
            new Claim(JwtRegisteredClaimNames.Email, user.Email),

            new Claim("role", role), // You can dynamically set the role from your DB
        };



            var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes( _configuration["Jwt:Key"]!));
            var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);

            var token = new JwtSecurityToken(
                _configuration["Jwt:Issuer"],
                _configuration["Jwt:Audience"],
                claims,
                expires: DateTime.Now.AddDays(15),
                signingCredentials: credentials);

            return new JwtSecurityTokenHandler().WriteToken(token);
        }
        [HttpGet("logout")]
      
        public async Task<IActionResult> Logout()
        {
            var user = User.Identity.Name;
         
            

            await _signInManager.SignOutAsync();
            //HttpContext.Session.Clear(); // Clear session data
            Response.Cookies.Delete(".AspNetCore.Identity.Application");
           
            Console.WriteLine("cookie is deleted");
            return Ok();
        }




        [HttpPost("register")]
        public async Task<IActionResult> Register(Register model)
        {
           
                var employee = await _context.Employee.FirstOrDefaultAsync(e => e.Email == model.Email);
                if (employee == null)
                {
                    // If the email does not exist in the employee table

                    return NotFound(new { message = "Employee with the provided email does not exist." });
                }
              

                User user = new() { UserName = model.Email, Email = model.Email };
                string a = model.Password;
                // Console.WriteLine(a);
                var result = await _userManager.CreateAsync(user, a);

                if (result.Succeeded)
                {
                    var role = employee.Role;
                    await _userManager.AddToRoleAsync(user, role);
                    await _signInManager.SignInAsync(user, isPersistent: false);

                    var user1 = await _context.Employee.FirstOrDefaultAsync(e => e.Email == model.Email);



                    return Ok();
                }
                else{

                    return BadRequest(new { message = "There was an issue processing the request." });


                }

           

        }




    }
}
