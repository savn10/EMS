﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using EmployeeCrud.Data;
using EmployeeCrud.Model;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;

namespace EmployeeCrud.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize(Roles ="Admin")]
    
    public class ManagersController : ControllerBase
    {
        private readonly ApplicationDbContext _context;
        private readonly UserManager<User> _userManager;

        public ManagersController(ApplicationDbContext context, UserManager<User> userManager)
        {
            _context = context;
            _userManager = userManager;
        }

        // GET: api/Managers
        [HttpGet("Index")]
        public async Task<ActionResult<IEnumerable<Manager>>> GetManagers()
        {
            return  await _context.Managers
        .Include(m => m.ManagerEmployee ).Include(m=>m.Department) 
        .ToListAsync();
        }

        // GET: api/Managers/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Manager>> GetManager(int id)
        {
            var manager = await _context.Managers.FindAsync(id);

            if (manager == null)
            {
                return NotFound();
            }

            return manager;
        }

        // PUT: api/Managers/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> PutManager(int id, Manager manager)
        {
            if (id != manager.ManagerId)
            {
                return BadRequest();
            }

            _context.Entry(manager).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!ManagerExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Managers
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost("Create")]
        public async Task<ActionResult<Manager>> PostManager(Manager manager)
        {
            var emp = await _context.Employee.FirstOrDefaultAsync(e => e.EmployeeId == manager.ManagerId);
            if(emp != null)
            {
                manager.DepartmentId = emp.DepartmentId;
                emp.Role = "Manager";

                manager.ManagerEmployee = emp;
                _context.Employee.Update(emp);
                Console.WriteLine("HIiii");
                Console.WriteLine(manager.ManagerEmployee.EmployeeName);
                _context.Managers.Add(manager);
                var user = await _userManager.FindByEmailAsync(emp.Email);


                var roles = await _userManager.GetRolesAsync(user);
                if (roles.Contains("Employee"))
                {
                    await _userManager.RemoveFromRoleAsync(user, "Employee");
                    await _userManager.AddToRoleAsync(user, "Manager");
                }

                try
                {
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateException)
                {
                    if (ManagerExists(manager.ManagerId))
                    {
                        return Conflict();
                    }
                    else
                    {
                        throw;
                    }
                }

                return Ok();
            }
            return NotFound();
           
        }

        // DELETE: api/Managers/5
        [HttpDelete("Delete/{id}")]
        public async Task<IActionResult> DeleteManager(int id)
        {
            var manager = await _context.Managers.FindAsync(id);
            if (manager == null)
            {
                return NotFound();
            }
            var emp =  _context.Employee.Find(id);

            emp.Role = "Employee";
            var user = await _userManager.FindByEmailAsync(emp.Email);
            var roles = await _userManager.GetRolesAsync(user);
            if (roles.Contains("Manager"))
            {
                await _userManager.RemoveFromRoleAsync(user, "Manager");
                await _userManager.AddToRoleAsync(user, "Employee");
            }

            _context.Managers.Remove(manager);
            _context.Employee.Update(emp);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool ManagerExists(int id)
        {
            return _context.Managers.Any(e => e.ManagerId == id);
        }
    }
}
