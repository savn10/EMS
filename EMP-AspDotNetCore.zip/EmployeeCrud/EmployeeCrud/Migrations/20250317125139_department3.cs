﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace EmployeeCrud.Migrations
{
    /// <inheritdoc />
    public partial class department3 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql("ALTER TABLE [Employee] DROP CONSTRAINT [PK_Employee]");

            // Step 2: Drop the existing EmployeeId column
            migrationBuilder.DropColumn(
                name: "EmployeeId",
                table: "Employee");

            // Step 3: Recreate the EmployeeId column with the new sequence
            migrationBuilder.AddColumn<int>(
                name: "EmployeeId",
                table: "Employee",
                type: "int",
                nullable: false,
                defaultValueSql: "NEXT VALUE FOR dbo.EmployeeIdSequence");

            // Step 4: Re-add the primary key constraint on EmployeeId
            migrationBuilder.AddPrimaryKey(
                name: "PK_Employee",
                table: "Employee",
                column: "EmployeeId");


            migrationBuilder.Sql("ALTER TABLE [Employee] DROP CONSTRAINT [FK_Employee_Departments_DepartmentId]");
            // Step 5: Do the same for DepartmentId (if needed)
            migrationBuilder.Sql("ALTER TABLE [Departments] DROP CONSTRAINT [PK_Departments]");

            // Step 6: Drop the existing DepartmentId column
            migrationBuilder.DropColumn(
                name: "DepartmentId",
                table: "Departments");

            // Step 7: Recreate the DepartmentId column with the new sequence
            migrationBuilder.AddColumn<int>(
                name: "DepartmentId",
                table: "Departments",
                type: "int",
                nullable: false,
                defaultValueSql: "NEXT VALUE FOR dbo.DepartmentIdSequence");

            // Step 8: Re-add the primary key constraint on DepartmentId
            migrationBuilder.AddPrimaryKey(
                name: "PK_Departments",
                table: "Departments",
                column: "DepartmentId");
            migrationBuilder.AddForeignKey(
               name: "FK_Employee_Departments_DepartmentId",
               table: "Employee",
               column: "DepartmentId",
               principalTable: "Departments",
               principalColumn: "DepartmentId",
               onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql("ALTER TABLE [Employee] DROP CONSTRAINT [PK_Employee]");

            // Step 2: Drop the EmployeeId column
            migrationBuilder.DropColumn(
                name: "EmployeeId",
                table: "Employee");

            // Step 3: Recreate EmployeeId column as Identity
            migrationBuilder.AddColumn<int>(
                name: "EmployeeId",
                table: "Employee",
                type: "int",
                nullable: false)
                .Annotation("SqlServer:Identity", "1, 1");

            // Step 4: Re-add the primary key constraint on EmployeeId
            migrationBuilder.AddPrimaryKey(
                name: "PK_Employee",
                table: "Employee",
                column: "EmployeeId");
           


            migrationBuilder.Sql("ALTER TABLE [Employee] DROP CONSTRAINT [FK_Employee_Departments_DepartmentId]");
            // Step 5: Drop the primary key constraint on DepartmentId (if needed)
            migrationBuilder.Sql("ALTER TABLE [Departments] DROP CONSTRAINT [PK_Departments]");

            // Step 6: Drop the DepartmentId column
            migrationBuilder.DropColumn(
                name: "DepartmentId",
                table: "Departments");

            // Step 7: Recreate DepartmentId column as Identity
            migrationBuilder.AddColumn<int>(
                name: "DepartmentId",
                table: "Departments",
                type: "int",
                nullable: false)
                .Annotation("SqlServer:Identity", "1, 1");

            // Step 8: Re-add the primary key constraint on DepartmentId
            migrationBuilder.AddPrimaryKey(
                name: "PK_Departments",
                table: "Departments",
                column: "DepartmentId");

            migrationBuilder.AddForeignKey(
               name: "FK_Employee_Departments_DepartmentId",
               table: "Employee",
               column: "DepartmentId",
               principalTable: "Departments",
               principalColumn: "DepartmentId",
               onDelete: ReferentialAction.Cascade);

        }
    }
}
