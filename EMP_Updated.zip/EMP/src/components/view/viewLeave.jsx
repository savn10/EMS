import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

const viewLeave = async (leaveId) => {
  const [leave, setLeave] = useState([]);
  const [approversCmnt, setApproversCmnt] = useState("");
  const navigate = useNavigate();
  useEffect(() => {
    const leave = async (leaveId) => {
      try {
        const response = await detailsLeave(leaveId);
        setLeave(response);
      } catch (error) {
        console.log("Error fetch leave details", error);
      }
    };
    leave();
  }, []);
  const handleApprove = async (status) => {
    // Handle the logic for approval/rejection
    const formData = {
      approversCmnt: approversCmnt,
      status: status,
      id: leave.id,
    };
    const response = await updateLeave(formDate);
  };

  return (
    <div>
      <h1>Leave Details</h1>
      <dl className="row">
        <dt className="col-sm-2">ID</dt>
        <dd className="col-sm-10">{leave.Id}</dd>

        <dt className="col-sm-2">Start Date</dt>
        <dd className="col-sm-10">
          {new Date(leave.startDate).toLocaleDateString()}
        </dd>

        <dt className="col-sm-2">End Date</dt>
        <dd className="col-sm-10">
          {new Date(leave.endDate).toLocaleDateString()}
        </dd>

        <dt className="col-sm-2">Created At</dt>
        <dd className="col-sm-10">{}</dd>

        <dt className="col-sm-2">Days</dt>
        <dd className="col-sm-10">{leave.noOfDays}</dd>
      </dl>

      <form>
        <div className="form-group mt-1">
          <label htmlFor="approversCmnt" className="control-label">
            Approver's Comment
          </label>
          <input
            id="approversCmnt"
            className="form-control"
            value={approversCmnt}
            onChange={(e) => setApproversCmnt(e.target.value)}
          />
        </div>

        <button
          type="button"
          className="btn btn-success mt-2 btn-sm"
          onClick={() => handleApprove("Approved")}
        >
          Approve
        </button>

        <button
          type="button"
          className="btn btn-danger mt-2 btn-sm"
          onClick={() => handleApprove("Rejected")}
        >
          Reject
        </button>
      </form>

      <button
        className="btn btn-secondary btn-sm mt-2"
        onClick={() => navigate("/LeaveIndex")}
      >
        Back
      </button>
    </div>
  );
};

export default viewLeave;
