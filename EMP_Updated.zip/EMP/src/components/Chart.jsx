import React from 'react'

const Chart = () => {



    
  return (


    <div>Chart</div>
  )
}

export default Chart