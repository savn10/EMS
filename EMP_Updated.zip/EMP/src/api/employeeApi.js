import { axiosInstance } from "./axiosInstance";

export const createEmployee = async (userData) => {
  try {
    const response = axiosInstance.post("/Employee/Create", userData);
    return response;
  } catch (error) {
    console.error("Error creating employee", error);
    throw error;
  }
};
export const fetchEmployee = async (userEmail) => {
  try {
    const response = axiosInstance.post("/Employee/Index", userEmail);
    console.log((await response).data, "this is the response");
    const employeeData = (await response).data;
    return employeeData;
  } catch (error) {
    console.error("Error creating employee", error);
    throw error;
  }
};
export const deleteEmployee = async (id) => {
  try {
    const response = axiosInstance.delete(`/Employee/Delete/${id}`);
    console.log("Employee deleted successfully: ", (await response).data);
    return (await response).data;
  } catch (error) {
    console.error("Error Deleting employee", error);
    throw error;
  }
};

export const dashBoard = async (email) => {
  try {
    const response = axiosInstance.post("/Employee/dashboard", email);
    console.log((await response).data);
    return (await response).data;
  } catch (error) {
    console.error("Error Deleting employee", error);
    throw error;
  }
};
export const employeeCount = async (email) => {
  try {
    const response = await axiosInstance.post("/Employee/EmployeeCount", {
      email,
    });
    console.log("hiiii", response.data);
    return response.data;
  } catch (error) {
    throw error;
  }
};
