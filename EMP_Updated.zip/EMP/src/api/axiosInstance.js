import axios from "axios";
import { getTokenFromCookie } from "../helpers/helper";

const API_BASE_URL = "https://localhost:7265/api";

export const axiosInstance = axios.create({
  baseURL: API_BASE_URL,
  withCredentials: true, // Important for CORS with credentials
});

axiosInstance.interceptors.request.use(async (config) => {
  const accessToken = getTokenFromCookie("accessToken");

  console.log("to check if access token is there: ", accessToken);
  if (accessToken) {
    config.headers["Authorization"] = `Bearer ${accessToken}`;
    console.log(config.headers);
  } else {
    console.error("No access token found.");
  }
  return config;
});
