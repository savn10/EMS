import { axiosInstance } from "./axiosInstance";

export const fetchManager = async () => {
  try {
    const response = await axiosInstance.get("/Managers/Index");

    const managers = (await response).data;
    console.log(" getting manager", managers);
    return managers;
  } catch (error) {
    console.error("Error getting manager", error);
    throw error;
  }
};

export const createManager = async (userData) => {
  try {
    console.log("Not running");
    const response = await axiosInstance.post("/Managers/Create", userData);
    return response;
  } catch (error) {
    console.error("Error adding manager", error);
    throw error;
  }
};

export const deleteManager = async (id) => {
  try {
    console.log(id);
    await axiosInstance.delete(`/Managers/Delete/${id}`);
  } catch (error) {
    console.error("Error deleting manager", error);
  }
};
export const getManager = async (id) => {
  try {
    console.log("Not running");
    const response = await axiosInstance.post(`/Managers/details/${id}`);
    return response;
  } catch (error) {
    console.error("Error adding manager", error);
    throw error;
  }
};
