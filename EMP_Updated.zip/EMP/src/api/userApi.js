import axios from "axios";

import { axiosInstance } from "./axiosInstance";

export const userSignIn = async (userData) => {
  try {
    const response = await axios.post(
      "https://localhost:7265/api/auth/login",
      userData
    );
    console.log(response.data);
    return response.data;
  } catch (error) {
    console.error("Error Signing in Passenger:", error);
    throw error;
  }
};

export const userLogOut = async () => {
  try {
    const response = await axiosInstance.get("/auth/logout");
    return response.data;
  } catch (error) {
    console.error("Error Signing in Passenger:", error);
    throw error;
  }
};
export const userRegister = async (userData) => {
  try {
    const response = await axiosInstance.post("/auth/register", userData);
    console.log(response.data);
    return response;
  } catch (error) {
    console.log("Error in signing in", error.response.data);
    throw error;
  }
};
