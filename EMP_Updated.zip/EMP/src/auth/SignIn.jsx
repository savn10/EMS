import { useState } from "react";
import {
  getUserFromLocalStorage,
  isValidEmail,
  isValidPassword,
  removeTokenCookie,
  removeUserFromLocalStorage,
  setUserToLocalStorage,
} from "../helpers/helper";
import { Link, useNavigate } from "react-router-dom";
import { userSignIn } from "../api/userApi";

const SignIn = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();

    setError("");
    if (!isValidEmail({ email, setError })) {
      return;
    }
    const userSignInData = {
      email: email,
      password: password,
    };
    setIsLoading(true);
    try {
      const responseData = await userSignIn(userSignInData);
      const userResponse = {
        accessToken: responseData.token,
        userEmail: responseData.userDetails.email,
        userName: responseData.userDetails.employeeName,
        userRole: responseData.userDetails.role,
      };
      console.log("Login Response Data: ", userResponse);
      setUserToLocalStorage(userResponse);

      navigate("/Dashboard");
      window.location.reload();
    } catch (error) {
      setError(error.response.data);
      console.error("SignIn error:", error.response.data);
    }
    setIsLoading(false);
  };

  return (
    <div className="body1">
      <div className="container ">
        <div className="home-card first1">
          <h1>Login</h1>
          <form onSubmit={handleSubmit}>
            <div className="form-group">
              <label htmlFor="email" className="control-label mb-0 mt-2">
                Email
              </label>
              <input
                type="email"
                placeholder="Email"
                className="form-control"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </div>
            <div className="form-group">
              <label htmlFor="password" className="form-label mb-0 mt-2">
                Password
              </label>
              <input
                type="password"
                placeholder="Password"
                className="form-control"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />

              {error && (
                <>
                  <br></br>
                  <span className="text-danger">{error}</span>
                </>
              )}
            </div>

            <button type="submit" className="btn btn-dark mt-3">
              Login
            </button>
            <div>
              <p>
                Don't have an account? <Link to="/register">Register</Link>
              </p>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default SignIn;
