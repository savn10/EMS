import React, { useEffect, useState } from "react";
import { deleteLeave, viewStatus } from "../../api/leaveApi";
import "./LeaveRequest.css";
import { useNavigate } from "react-router-dom";
export const ViewStatus = () => {
  const navigate = useNavigate();
  const [change, setChange] = useState(0);
  const [leaveRequests, setLeaveRequests] = useState([]);
  useEffect(() => {
    var userEmail = localStorage.getItem("userEmail");
    userEmail = userEmail.replace(/"/g, "");
    var userData = {
      Email: userEmail,
    };
    const status = async () => {
      try {
        const response = await viewStatus(userData);
        setLeaveRequests(response);
      } catch (error) {
        console.log(error);
      }
    };
    status();
  }, [change]);
  const onDeleteClick = async (id) => {
    try {
      const response = await deleteLeave(id);
      setChange(change + 1);
    } catch (error) {
      console.log(error);
    }
  };

  return (
    <div className="body">
      <h2> Leave Updates</h2>
      <div className="table-responsive">
        <table className="table table-striped table-bordered mt-2">
          <thead className="thead-dark">
            <tr>
              <th>Id</th>
              <th>Start Date</th>
              <th>End Date</th>
              <th>Reason</th>
              <th>Days</th>
              <th>status</th>
            </tr>
          </thead>
          <tbody>
            {leaveRequests.map((leaveRequest, index) => {
              // Calculate days
              return (
                <tr key={index}>
                  <td>{leaveRequest.id}</td>
                  <td>
                    {new Date(leaveRequest.startDate).toLocaleDateString()}
                  </td>
                  <td>{new Date(leaveRequest.endDate).toLocaleDateString()}</td>
                  <td>{leaveRequest.reason}</td>
                  <td>{leaveRequest.noOfDays}</td>
                  <td>
                    {leaveRequest.status === "Pending" ? (
                      <div className="btn-group">
                        <button
                          className="btn btn-secondary btn-sm"
                          onClick={() => onDeleteClick(leaveRequest.id)}
                        >
                          Revoke
                        </button>
                      </div>
                    ) : leaveRequest.status === "Approved" ? (
                      <span className="badge bg-success custom-badge-large">
                        Approved
                      </span>
                    ) : leaveRequest.status === "Rejected" ? (
                      <span className="badge bg-danger">Rejected</span>
                    ) : (
                      <span className="badge bg-secondary">Unknown</span> // Fallback for undefined statuses
                    )}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
        <button
          className="btn btn-secondary btn-sm mt-2"
          onClick={() => navigate("/ApplyLeave")}
        >
          Back
        </button>
      </div>
    </div>
  );
};
