import React, { useEffect, useState } from "react";
import { dashBoard } from "../api/employeeApi";
import AdminManagerDashboard from "./AdminManagerDashboard";

const Dashboard = () => {
  const [data, setData] = useState();
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const fetchdash = async () => {
      var userEmail = localStorage.getItem("userEmail");
      userEmail = userEmail.replace(/"/g, "");
      console.log("Email", userEmail);
      var userData = {
        email: userEmail,
      };
      try {
        const response = await dashBoard(userData);
        console.log(response, "resp");
        setData(response);
        setLoading(true);
      } catch (error) {
        console.log(error);
      }
    };
    fetchdash();
  }, []);

  return (
    <div>
      {loading && (
        <>
          <div className="body">
            <h1
              style={{
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
                marginTop: "20px",
              }}
              className="mt-3"
            >
              Welcome to your DashBoard
            </h1>

            <div className="container2">
               <div className="home-card second1 ">
                <div className="heading ">DashBoard</div>
                <br></br>

                <dl className="row">
                  <dt className="col-sm-3">Employee ID</dt>
                  <dd className="col-sm-9">{data.employeeId}</dd>

                  <dt className="col-sm-3">Name</dt>
                  <dd className="col-sm-9">{data.employeeName}</dd>

                  <dt className="col-sm-3">Email</dt>
                  <dd className="col-sm-9">{data.email}</dd>

                  <dt className="col-sm-3">Role</dt>
                  <dd className="col-sm-9">{data.role}</dd>

                  <dt className="col-sm-3">Leave Days</dt>
                  <dd className="col-sm-9">{data.leaveDays}</dd>

                  <dt className="col-sm-3">Department</dt>
                  <dd className="col-sm-9">{data.departmentName}</dd>

                  <dt className="col-sm-3">Manager</dt>
                  <dd className="col-sm-9">{data.managerName}</dd>
                </dl>
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
};

export default Dashboard;
