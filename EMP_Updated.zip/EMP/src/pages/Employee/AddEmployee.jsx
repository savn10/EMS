import { useEffect, useState } from "react";
import { createEmployee } from "../../api/employeeApi";
import { fetchDept } from "../../api/departmentApi";
import { useNavigate } from "react-router-dom";

export const Employee = () => {
  const navigate = useNavigate();
  const [employeeName, setEmployeeName] = useState("");
  const [email, setEmail] = useState("");
  const [phoneNumber, setPhoneNumber] = useState("");
  const [role, setRole] = useState("");
  const [gender, setGender] = useState("");
  const [hireDate, setHireDate] = useState("");
  const [departmentId, setDepartmentId] = useState();
  const [leaveDays, setLeaveDays] = useState();
  const [errors, setErrors] = useState({
    EmployeeName: "",
    Email: "",
    PhoneNumber: "",
    Role: "",
    Gender: "",
    HireDate: "",
    DepartmentId: "",
    LeaveDays: "",
  });

  const [departments, setDepartments] = useState(new Map());

  useEffect(() => {
    const fetchDepartments = async () => {
      try {
        const response = await fetchDept();
        const deptMap = new Map();
        response.forEach((department) => {
          deptMap.set(department.departmentId, department.departmentName);
        }); // Assuming fetchDept is an async function
        setDepartments(deptMap); // Assuming response is an array of departments
      } catch (error) {
        console.error("Error fetching departments:", error);
      }
    };

    fetchDepartments();
  }, []);

  const validationForm = async () => {
    console.log("tjis s working ");
    let formErrors = { ...errors };
    let isValid = true;

    // Validate EmployeeName
    if (!employeeName) {
      formErrors.EmployeeName = "Name is required.";
      isValid = false;
    }

    // Validate Email
    const emailRegex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
    if (!email || !emailRegex.test(email)) {
      formErrors.Email = "Please enter a valid email address.";
      isValid = false;
    }

    // Validate PhoneNumber
    const phoneRegex = /^[0-9]{10,13}$/;
    if (!phoneNumber || !phoneRegex.test(phoneNumber)) {
      formErrors.PhoneNumber = "Phone number must be between 10 and 13 digits.";
      isValid = false;
    }

    // Validate Role
    if (!role) {
      formErrors.Role = "Role is required.";
      isValid = false;
    }

    // Validate HireDate
    if (!hireDate) {
      formErrors.HireDate = "Hire date is required.";
      isValid = false;
    }

    // if (await checkMail(employee.Email)) {
    //   formErrors.Email = "Email already exists";
    //   isValid = false;
    // }

    if (new Date(hireDate).getTime() > Date.now()) {
      formErrors.HireDate = "Hire date cant be in future.";
      isValid = false;
    }

    // Validate DepartmentId

    // Validate LeaveDays
    if (leaveDays < 0) {
      formErrors.LeaveDays = "Leave days cannot be negative.";
      isValid = false;
    }

    setErrors(formErrors);
    return isValid;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (await validationForm()) {
      const userData = {
        EmployeeName: employeeName,
        Email: email,
        PhoneNumber: phoneNumber,
        Role: role,
        Gender: gender,
        HireDate: hireDate,
        DepartmentId: departmentId,
        LeaveDays: leaveDays,
      };

      try {
        const response = createEmployee(userData);
        if ((await response).status == 200) {
          alert("the employee is successfully added!");
          navigate("/EmployeeHome");
        } else {
          console.log(await response.text);
        }
      } catch (error) {
        console.log("Error adding emp", error);
      }
    }
  };

  return (
    <div className="body">
      <h1>Create Employee</h1>
      <div className="create-forms">
        <form onSubmit={handleSubmit}>
          <div className="form-group row">
            <div>
              <label htmlFor="EmployeeName" className="control-label">
                Name
              </label>
              <input
                className="form-control"
                type="text"
                id="EmployeeName"
                name="EmployeeName"
                value={employeeName}
                onChange={(e) => setEmployeeName(e.target.value)}
                required
              />
              {errors.EmployeeName && (
                <small className="text-danger">{errors.EmployeeName}</small>
              )}
            </div>
            <div>
              <label htmlFor="Email" className="control-label">
                Email
              </label>
              <input
                className="form-control"
                type="email"
                id="Email"
                name="Email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
              {errors.Email && (
                <small className="text-danger">{errors.Email}</small>
              )}
            </div>
            <div>
              <label htmlFor="PhoneNumber" className="control-label">
                Phone Number
              </label>
              <input
                className="form-control"
                type="text"
                id="PhoneNumber"
                name="PhoneNumber"
                value={phoneNumber}
                onChange={(e) => setPhoneNumber(e.target.value)}
                required
                minLength={10}
                maxLength={13}
              />
            </div>
            <div>
              <label htmlFor="Role" className="control-label">
                Role
              </label>
              <select
                className="form-control"
                id="Role"
                name="Role"
                value={role}
                onChange={(e) => setRole(e.target.value)}
                required
              >
                <option value="">Select a Role</option>
                <option value="Admin">Admin</option>
                <option value="Employee">Employee</option>
              </select>
              {errors.Role && (
                <small className="text-danger">{errors.Role}</small>
              )}
            </div>
            <div>
              <label htmlFor="Gender" className="control-label">
                Gender
              </label>
              <select
                className="form-control"
                id="Gender"
                name="Gender"
                value={gender}
                onChange={(e) => setGender(e.target.value)}
                required
              >
                <option value="">Select your Gender</option>
                <option value="Male">Male</option>
                <option value="Female">Female</option>
                <option value="Trans Person">Trans Person</option>
              </select>
              {errors.Gender && (
                <small className="text-danger">{errors.Gender}</small>
              )}
            </div>
            <div>
              <label htmlFor="HireDate" className="control-label">
                Hire Date
              </label>
              <input
                className="form-control"
                type="date"
                id="HireDate"
                name="HireDate"
                value={hireDate}
                onChange={(e) => setHireDate(e.target.value)}
                required
              />
              {errors.HireDate && (
                <small className="text-danger">{errors.HireDate}</small>
              )}
            </div>
            <div>
              <label htmlFor="DepartmentId" className="control-label">
                Department Name
              </label>
              <select
                className="form-control"
                id="DepartmentId"
                name="DepartmentId"
                value={departmentId}
                onChange={(e) => setDepartmentId(e.target.value)}
                required
              >
                <option value="">Select a Department</option>

                {[...departments].map(([deptId, deptName]) => (
                  <option key={deptId} value={deptId}>
                    {deptName}
                  </option>
                ))}
              </select>
              {errors.DepartmentId && (
                <small className="text-danger">{errors.DepartmentId}</small>
              )}
            </div>
            <div>
              <label htmlFor="LeaveDays" className="control-label">
                Leave Days
              </label>
              <input
                className="form-control"
                type="number"
                id="LeaveDays"
                name="LeaveDays"
                value={leaveDays}
                onChange={(e) => setLeaveDays(e.target.value)}
                required
              />
              {errors.LeaveDays && (
                <small className="text-danger">{errors.LeaveDays}</small>
              )}
            </div>
          </div>
          <button type="submit" className="btn btn-dark mt-3">
            Submit
          </button>
        </form>
        <button
          className="btn btn-secondary btn-sm mt-2 p-1"
          onClick={() => navigate("/EmployeeHome")}
        >
         Go Back
        </button>
      </div>
    </div>
  );
};
