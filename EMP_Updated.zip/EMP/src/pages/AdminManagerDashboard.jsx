import React, { useEffect, useState } from "react";
import { employeeCount } from "../api/employeeApi";
import { Pie, Bar } from "react-chartjs-2";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
  ArcElement,
} from "chart.js";

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
  ArcElement
);

const AdminManagerDashboard = () => {
  const [data, setData] = useState(null); // Changed initial state to null
  const [loaded, setLoading] = useState(false);

  useEffect(() => {
    var userEmail = localStorage.getItem("userEmail");
    userEmail = userEmail.replace(/"/g, "");

    const getEmployeeNumbers = async () => {
      const response = await employeeCount(userEmail);
      console.log(response);

      // Assuming response is like { malecount: 7, totalcount: 9 }
      setData(response);
      setLoading(true);
    };
    getEmployeeNumbers();
  }, []);

  // If data is available, prepare the pie chart data
  const chartData = data
    ? {
        labels: ["Male", "Female"],
        datasets: [
          {
            label: "Gender Distribution",
            data: [data.malecount, data.totalcount - data.malecount], // Female count is total count - male count
            backgroundColor: ["#003F5C", "#5F9EA0"],
            hoverBackgroundColor: ["#003F5C", "#5F9EA0"],
            borderColor: ["#DDDDDD", "#DDDDDD"],
          },
        ],
      }
    : {};
  const barChartData =
    data && data.departments
      ? {
          labels: data.departments.map((dept) => dept.departmentName), // Department names
          datasets: [
            {
              label: "Number of Employees",
              data: data.departments.map((dept) => dept.employeeCount), // Employee count per department
              backgroundColor: "#FF6384", // Bar color
              borderColor: "#FF6384",
              borderWidth: 1,
            },
          ],
        }
      : {};

  return (
    <div>
      {loaded && data ? (
        <>
          <div className="heading1 ">
            {" "}
            {localStorage.getItem("userRole").replace(/"/g, "")} DashBoard
          </div>
          <div className="container">
            <div className="home-card first2">
              <h4
                style={{
                  fontSize: "15px",
                  color: "gray",
                }}
              >
                Total Employees Count
              </h4>
              <div
                style={{
                  width: "200px",
                  height: "200px",
                }}
              >
                <Pie data={chartData} />
              </div>
              <div style={{ textAlign: "center" }}>
                <p>
                  Total Count:{" "}
                  {data.malecount + (data.totalcount - data.malecount)}
                </p>
              </div>
            </div>
            {localStorage.getItem("userRole").replace(/"/g, "") == "Admin" && (
              <>
                <div className="home-card second2">
                  <h4 style={{ fontSize: "15px", color: "gray" }}>
                    Employee Count by Department
                  </h4>
                  <div style={{ width: "500px", height: "300px" }}>
                    <Bar data={barChartData} options={{ responsive: true }} />
                  </div>
                </div>
              </>
            )}
          </div>
        </>
      ) : (
        <p>Loading...</p>
      )}
    </div>
  );
};

export default AdminManagerDashboard;
