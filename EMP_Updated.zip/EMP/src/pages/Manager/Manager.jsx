import { useEffect, useState } from "react";
import {
  createManager,
  deleteManager,
  fetchManager,
  getManager,
} from "../../api/managerApi";
import "../../App.css";
import { getUserFromLocalStorage } from "../../helpers/helper";

const Manager = () => {
  const [manager, setManager] = useState({
    ManagerId: "",
  });
  const [data, setData] = useState();
  const [mang, setMang] = useState([]);
  const [change, setChange] = useState(0);
  const [load, setLoad] = useState(false);
  const [err, setErr] = useState();
  useEffect(() => {
    const fetchManagers = async () => {
      setLoad(false);
      try {
        const response = await fetchManager();

        setMang(response);
      } catch (error) {
        console.error("Error fetching manager", error);
      }
    };
    fetchManagers();
  }, [change]);
  function handleChange(event) {
    setLoad(false);
    setErr();
    const { name, value } = event.target;

    setManager({
      ...manager,
      [name]: value,
    });
  }
  const handleSubmit = async (e) => {
    const userData = {
      managerId: manager.ManagerId,
    };

    e.preventDefault();
    try {
      const response = await createManager(userData);

      setChange(change + 1);
    } catch (error) {
      setErr(error.response.data);
      // console.log("Error adding manager", error);
    }
  };
  const handleManager = async (e) => {
    // const userData = {
    //   managerId: manager.ManagerId,
    // };
    e.preventDefault();
    try {
      const response = await getManager(manager.ManagerId);
      setData(response.data);
      console.log(response.data);
      setLoad(true);
    } catch (error) {
      console.log(error.response.data);
      setErr(error.response.data);
    }
  };

  return (
    <div className="body">
      <div className="container">
        <div className="home-card first11 ">
          <div className="heading ">Create Manager</div>

          <div>
            <form onSubmit={handleManager}>
              <div className="form-group row">
                <div>
                  <label
                    htmlFor="ManagerId"
                    className="control-label mt-3 p-l-3 "
                  >
                    Manager
                  </label>
                  <input
                    className="form-control mt-2"
                    type="text"
                    id="ManagerId"
                    name="ManagerId"
                    value={manager.ManagerId}
                    onChange={handleChange}
                    required
                  />

                  <button
                    onSubmit={() => handleManager}
                    className="btn btn-dark mt-2  "
                  >
                    Details
                  </button>
                  {err && (
                    <>
                      <br></br>
                      <span className="text-danger mt-2">{err}</span>
                    </>
                  )}

                  {load && (
                    <>
                      <dl className="row mt-2">
                        <dt className="col-sm-3">ID</dt>
                        <dd className="col-sm-9">{data.employeeId}</dd>

                        <dt className="col-sm-3">Name</dt>
                        <dd className="col-sm-9">{data.name}</dd>
                        <dt className="col-sm-3">Dept</dt>
                        <dd className="col-sm-9">{data.departmentName}</dd>
                      </dl>
                    </>
                  )}
                </div>
              </div>
            </form>
            {load && (
              <>
                <form onSubmit={handleSubmit}>
                  <div className="d-flex justify-content-center">
                    <button type="submit" className="btn btn-dark mt-2  ">
                      Submit
                    </button>
                  </div>
                  {err && (
                    <>
                      <br></br>
                      <span className="text-danger">{err}</span>
                    </>
                  )}
                </form>
              </>
            )}
          </div>
        </div>
        <div className="home-card second">
          <h2>Managers List</h2>

          <div className="table-responsive">
            <table className="table table-striped table-bordered mt-2">
              <thead className="thead-dark">
                <tr>
                  <th>Manager Id</th>
                  <th>Department Name</th>
                  <th>Manager</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                {mang.map((man, index) => (
                  <tr key={index}>
                    <td>{man.managerId}</td>
                    <td>{man.department.departmentName}</td>
                    <td>{man.managerEmployee.employeeName}</td>
                    <td>
                      <div className="btn-group">
                        <button className="btn btn-secondary btn-sm  ml-2">
                          Edit
                        </button>
                        <button
                          className="btn btn-secondary btn-sm"
                          onClick={async () => {
                            await deleteManager(man.managerId);
                            setChange(change + 1);
                          }}
                        >
                          Delete
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Manager;
