import React, { useState, useEffect } from "react"; // Import necessary hooks
import { createDepartment, fetchDept } from "../../api/departmentApi"; // Assuming fetchDept is correctly imported

import "./Department.css";
import "../../../src/App.css";

const CreateDept = () => {
  const [departments, setDepartments] = useState([]);
  const [error, setError] = useState("");
  const [dept, setDept] = useState({
    DepartmentName: "",
  });

  const [change, setChange] = useState(0);

  useEffect(() => {
    const getDept = async () => {
      try {
        const response = await fetchDept();
        console.log("create func ", response);

        setDepartments(response);
      } catch (error) {
        setError("Failed to fetch departments");
        console.error(error);
      }
    };
    getDept();
  }, [change]); // Empty dependency array to call once on mount

  const handleSubmit = async (e) => {
    try {
      e.preventDefault();
      const resp = await createDepartment(dept);
      setChange(change + 1);
    } catch (error) {
      console.log(error);
    }
  };

  function handleChange(event) {
    const { name, value } = event.target;

    setDept({
      ...dept,
      [name]: value,
    });
  }
  return (
    <>
      <div className="body ">
        <div className="container">
          <div className="home-card first">
            <div className="heading">Create Department</div>

            <div>
              <form onSubmit={handleSubmit}>
                <div className="form-group row">
                  <label
                    htmlFor="DepartmentName"
                    className="control-label mt-3 p-l-3"
                  >
                    Department Name
                  </label>
                  <input
                    className="form-control w-75   m-2"
                    type="text"
                    id="DepartmentName"
                    name="DepartmentName"
                    value={dept.DepartmentName}
                    onChange={handleChange}
                    required
                  />
                  <div className="d-flex justify-content-center">
                    <button type="submit" className="btn btn-dark mt-3">
                      Submit
                    </button>
                  </div>
                </div>
              </form>
            </div>
          </div>

          <div className="home-card second">
            <h2>Departments List</h2>

            <div className="table-responsive">
              <table className="table table-striped table-bordered mt-2">
                <thead className="thead-dark">
                  <tr>
                    <th>Dept. Id</th>
                    <th>Department Name</th>
                  </tr>
                </thead>
                <tbody>
                  {departments.map((dep) => (
                    <tr key={dep.departmentId}>
                      {" "}
                      {/* Use departmentId as the key */}
                      <td>{dep.departmentId}</td>
                      <td>{dep.departmentName}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default CreateDept;
