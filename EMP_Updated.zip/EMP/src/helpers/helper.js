export const isValidEmail = ({ email, setError }) => {
  const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/; // Updated email regex
  if (emailRegex.test(email)) return true;
  else {
    setError("Please enter a valid email address.");
    return false;
  }
};

export const isValidPassword = ({ password, setError }) => {
  const pwdRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,}$/;
  if (pwdRegex.test(password)) return true;
  else {
    setError(
      "Password must be at least 8 characters long, contain at least one uppercase letter, one lowercase letter, and one digit."
    );
    return false;
  }
};
export const setTokenCookie = (name, value, expiryDays) => {
  const date = new Date();
  date.setTime(date.getTime() + expiryDays * 24 * 60 * 60 * 1000);
  console.log("set token cookie funtion" + value);
  document.cookie = `${name}=${value}; expires=${date.toUTCString()}; path=/; secure; samesite=strict`;
};
export const getTokenFromCookie = (name) => {
  const value = `; ${document.cookie}`;
  console.log(value);
  const parts = value.split(`; ${name}=`);
  if (parts.length === 2) return parts.pop().split(";").shift();
  return null;
};
export const removeTokenCookie = (name) => {
  document.cookie = `${name}=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/; secure; samesite=strict`;
};
export const setUserToLocalStorage = (userData) => {
  const { accessToken, userEmail, userName, userRole } = userData;
  // console.log("Access Token to Store: ", accessToken);
  // console.log("hiii", userEmail, userName);
  if (accessToken) {
    // Setting the token in a cookie for the user's session
    setTokenCookie("accessToken", accessToken, 5);

    localStorage.setItem("userName", JSON.stringify(userName));
    localStorage.setItem("userEmail", JSON.stringify(userEmail));
    localStorage.setItem("userRole", JSON.stringify(userRole));
    console.log("hiii", localStorage.getItem("userRole"));
    console.log("hello", localStorage.getItem("userEmail"));

    // Store token for 1 day
  } else {
    console.error("No access token to store.");
  }
};
export const getUserFromLocalStorage = (name) => {
  const response = JSON.parse(localStorage.getItem(name));
  return response;
};
export const removeUserFromLocalStorage = () => {
  localStorage.removeItem("userName");
  localStorage.removeItem("userEmail");
  localStorage.removeItem("userRole");
};
