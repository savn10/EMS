import "./App.css";
import SignIn from "./auth/SignIn";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import CreateDept from "./pages/Departments/CreateDept";

import "./../node_modules/bootstrap/dist/css/bootstrap.min.css";
import NavBar from "./components/navbar/NavBar";
import { Employee } from "./pages/Employee/AddEmployee";
import EmployeeHome from "./pages/Employee/EmployeeHome";
import Manager from "./pages/Manager/Manager";
import ApplyLeave from "./pages/LeaveRequest/ApplyLeave";
import LeaveRequests from "./pages/LeaveRequest/LeaveRequests";
import LeaveDetails from "./pages/LeaveRequest/LeaveDetails";
import { ViewStatus } from "./pages/LeaveRequest/ViewStatus";
import Register from "./auth/Register";
import Dashboard from "./pages/Dashboard";
import AdminManagerDashboard from "./pages/AdminManagerDashboard";

function App() {
  var role = localStorage.getItem("userRole");
  if (role != null) role = role.slice(1, -1);

  return (
    <>
      <NavBar />
      <div>
        <Routes>
          {role === null && (
            <>
              <Route path="/" element={<SignIn />} />
              <Route path="/signin" element={<SignIn />} />
              <Route path="/Register" element={<Register />} />
            </>
          )}
          {role === "Admin" && (
            <>
              <Route path="/department" element={<CreateDept />} />
              <Route path="/Employee" element={<Employee />} />
              <Route path="/EmployeeHome" element={<EmployeeHome />} />
              <Route path="/Manager" element={<Manager />} />
              <Route path="/LeaveRequests" element={<LeaveRequests />} />
              <Route path="/leave/details/:id" element={<LeaveDetails />} />
              <Route path="/Admin" element={<AdminManagerDashboard />} />
            </>
          )}
          {role === "Manager" && (
            <>
              <Route path="/EmployeeHome" element={<EmployeeHome />} />
              <Route path="/LeaveRequests" element={<LeaveRequests />} />
              <Route path="/leave/details/:id" element={<LeaveDetails />} />
              <Route path="/Manager" element={<AdminManagerDashboard />} />
            </>
          )}
          {role === "Employee" && (
            <>
              <Route path="/ApplyLeave" element={<ApplyLeave />} />
              <Route path="/ViewStatus" element={<ViewStatus />} />
            </>
          )}
          {role != null && (
            <>
              <Route path="/Dashboard" element={<Dashboard />} />
            </>
          )}
        </Routes>
      </div>
    </>
  );
}

export default App;
